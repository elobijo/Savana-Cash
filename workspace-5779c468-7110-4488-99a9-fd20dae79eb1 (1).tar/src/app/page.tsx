'use client';

import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { WalletProvider, useWallet } from '@/contexts/WalletContext';
import { WalletCreation } from '@/components/wallet/WalletCreation';
import { WalletBalance } from '@/components/wallet/WalletBalance';
import { SwapInterface } from '@/components/swap/SwapInterface';
import { HedgeInterface } from '@/components/hedge/HedgeInterface';
import { FarmInterface } from '@/components/farm/FarmInterface';
import { SettingsView } from '@/components/settings/SettingsView';
import { TopUpInterface } from '@/components/topup/TopUpInterface';
import { BottomNav, TopBar } from '@/components/layout/BottomNav';

function WalletApp() {
  const { state } = useWallet();
  const [activeView, setActiveView] = useState('wallet');
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    // Small delay for smooth transition
    const timer = setTimeout(() => setIsReady(true), 100);
    return () => clearTimeout(timer);
  }, []);

  // Show wallet creation if no wallet exists
  if (!state.wallet) {
    return <WalletCreation onComplete={() => {}} />;
  }

  const renderContent = () => {
    switch (activeView) {
      case 'wallet':
        return <WalletBalance onNavigate={setActiveView} />;
      case 'topup':
        return <TopUpInterface />;
      case 'swap':
        return <SwapInterface />;
      case 'hedge':
        return <HedgeInterface />;
      case 'farm':
        return <FarmInterface />;
      case 'settings':
        return <SettingsView />;
      default:
        return <WalletBalance onNavigate={setActiveView} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-950 via-orange-950 to-yellow-900">
      {/* African Pattern Background */}
      <div className="fixed inset-0 opacity-5 pointer-events-none">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M30 0L60 30L30 60L0 30L30 0z' fill='%23ffffff' fill-opacity='0.1'/%3E%3C/svg%3E")`,
          backgroundSize: '60px 60px',
        }} />
      </div>

      <TopBar onSettingsClick={() => setActiveView('settings')} />
      
      <main className="max-w-lg mx-auto px-4 py-4 pb-24 relative z-10">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeView}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
          >
            {renderContent()}
          </motion.div>
        </AnimatePresence>
      </main>

      <BottomNav activeView={activeView} onViewChange={setActiveView} />
    </div>
  );
}

export default function Home() {
  return (
    <WalletProvider>
      <WalletApp />
    </WalletProvider>
  );
}
