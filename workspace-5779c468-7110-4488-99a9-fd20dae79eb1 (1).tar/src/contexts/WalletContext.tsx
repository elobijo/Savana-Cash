'use client';

import React, { createContext, useContext, useReducer, useEffect, useCallback } from 'react';
import { 
  Wallet, 
  Transaction, 
  Token, 
  HedgePosition, 
  FarmPosition, 
  UserSettings,
  WalletState,
  AFRICAN_CURRENCIES,
} from '@/types';
import { 
  createWallet, 
  importWallet, 
  saveWalletToStorage, 
  loadWalletFromStorage,
  generateMockTransactions,
  saveSettingsToStorage,
  loadSettingsFromStorage,
} from '@/lib/wallet/utils';
import { DEFAULT_TOKENS, DEFAULT_SETTINGS } from '@/lib/wallet/constants';

// Action types
type WalletAction = 
  | { type: 'SET_WALLET'; payload: Wallet | null }
  | { type: 'SET_BALANCE'; payload: number }
  | { type: 'SET_TRANSACTIONS'; payload: Transaction[] }
  | { type: 'ADD_TRANSACTION'; payload: Transaction }
  | { type: 'SET_TOKENS'; payload: Token[] }
  | { type: 'UPDATE_TOKEN_BALANCE'; payload: { tokenId: string; balance: number } }
  | { type: 'SET_HEDGE_POSITIONS'; payload: HedgePosition[] }
  | { type: 'ADD_HEDGE_POSITION'; payload: HedgePosition }
  | { type: 'UPDATE_HEDGE_POSITION'; payload: HedgePosition }
  | { type: 'SET_FARM_POSITIONS'; payload: FarmPosition[] }
  | { type: 'ADD_FARM_POSITION'; payload: FarmPosition }
  | { type: 'UPDATE_FARM_POSITION'; payload: FarmPosition }
  | { type: 'SET_SETTINGS'; payload: UserSettings }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_ERROR'; payload: string | null }
  | { type: 'LOCK_WALLET' }
  | { type: 'UNLOCK_WALLET' }
  | { type: 'CLEAR_WALLET' };

// Initial state
const initialState: WalletState = {
  wallet: null,
  isLocked: false,
  transactions: [],
  tokens: DEFAULT_TOKENS,
  hedgePositions: [],
  farmPositions: [],
  settings: DEFAULT_SETTINGS,
  isLoading: false,
  error: null,
};

// Reducer
function walletReducer(state: WalletState, action: WalletAction): WalletState {
  switch (action.type) {
    case 'SET_WALLET':
      return { ...state, wallet: action.payload, isLocked: false };
    case 'SET_BALANCE':
      if (!state.wallet) return state;
      return {
        ...state,
        wallet: {
          ...state.wallet,
          addresses: state.wallet.addresses.map((addr, i) => 
            i === 0 ? { ...addr, balance: action.payload } : addr
          ),
        },
      };
    case 'SET_TRANSACTIONS':
      return { ...state, transactions: action.payload };
    case 'ADD_TRANSACTION':
      return { 
        ...state, 
        transactions: [action.payload, ...state.transactions] 
      };
    case 'SET_TOKENS':
      return { ...state, tokens: action.payload };
    case 'UPDATE_TOKEN_BALANCE':
      return {
        ...state,
        tokens: state.tokens.map(token =>
          token.id === action.payload.tokenId
            ? { ...token, balance: action.payload.balance }
            : token
        ),
      };
    case 'SET_HEDGE_POSITIONS':
      return { ...state, hedgePositions: action.payload };
    case 'ADD_HEDGE_POSITION':
      return { 
        ...state, 
        hedgePositions: [action.payload, ...state.hedgePositions] 
      };
    case 'UPDATE_HEDGE_POSITION':
      return {
        ...state,
        hedgePositions: state.hedgePositions.map(pos =>
          pos.id === action.payload.id ? action.payload : pos
        ),
      };
    case 'SET_FARM_POSITIONS':
      return { ...state, farmPositions: action.payload };
    case 'ADD_FARM_POSITION':
      return { 
        ...state, 
        farmPositions: [action.payload, ...state.farmPositions] 
      };
    case 'UPDATE_FARM_POSITION':
      return {
        ...state,
        farmPositions: state.farmPositions.map(pos =>
          pos.id === action.payload.id ? action.payload : pos
        ),
      };
    case 'SET_SETTINGS':
      return { ...state, settings: action.payload };
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };
    case 'SET_ERROR':
      return { ...state, error: action.payload };
    case 'LOCK_WALLET':
      return { ...state, isLocked: true };
    case 'UNLOCK_WALLET':
      return { ...state, isLocked: false };
    case 'CLEAR_WALLET':
      return { ...initialState };
    default:
      return state;
  }
}

// Context type
interface WalletContextType {
  state: WalletState;
  createNewWallet: (name?: string) => void;
  importExistingWallet: (mnemonic: string, name?: string) => boolean;
  lockWallet: () => void;
  unlockWallet: () => void;
  clearWallet: () => void;
  updateBalance: (balance: number) => void;
  setCurrency: (currencyCode: string) => void;
  setLanguage: (language: UserSettings['language']) => void;
  setTheme: (theme: UserSettings['theme']) => void;
  addHedgePosition: (position: HedgePosition) => void;
  updateHedgePosition: (position: HedgePosition) => void;
  addFarmPosition: (position: FarmPosition) => void;
  updateFarmPosition: (position: FarmPosition) => void;
  addTransaction: (transaction: Transaction) => void;
  getBchBalance: () => number;
  getFiatBalance: () => number;
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

// Provider component
export function WalletProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(walletReducer, initialState);

  // Load wallet from storage on mount
  useEffect(() => {
    const savedWallet = loadWalletFromStorage();
    if (savedWallet) {
      dispatch({ type: 'SET_WALLET', payload: savedWallet });
      
      // Generate mock transactions for demo
      if (savedWallet.addresses.length > 0) {
        const transactions = generateMockTransactions(savedWallet.addresses[0].address);
        dispatch({ type: 'SET_TRANSACTIONS', payload: transactions });
      }
    }

    const savedSettings = loadSettingsFromStorage() as UserSettings | null;
    if (savedSettings) {
      dispatch({ type: 'SET_SETTINGS', payload: savedSettings });
    }
  }, []);

  // Save wallet to storage when it changes
  useEffect(() => {
    if (state.wallet) {
      saveWalletToStorage(state.wallet);
    }
  }, [state.wallet]);

  // Save settings when they change
  useEffect(() => {
    saveSettingsToStorage(state.settings);
  }, [state.settings]);

  const createNewWallet = useCallback((name?: string) => {
    dispatch({ type: 'SET_LOADING', payload: true });
    try {
      const wallet = createWallet(name);
      dispatch({ type: 'SET_WALLET', payload: wallet });
      
      // Generate mock transactions
      const transactions = generateMockTransactions(wallet.addresses[0].address);
      dispatch({ type: 'SET_TRANSACTIONS', payload: transactions });
      
      // Set initial mock balance for demo
      const mockBalance = Math.random() * 2 + 0.5; // 0.5 - 2.5 BCH
      dispatch({ type: 'SET_BALANCE', payload: mockBalance * 100000000 });
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: 'Failed to create wallet' });
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  }, []);

  const importExistingWallet = useCallback((mnemonic: string, name?: string): boolean => {
    dispatch({ type: 'SET_LOADING', payload: true });
    try {
      const wallet = importWallet(mnemonic, name);
      if (wallet) {
        dispatch({ type: 'SET_WALLET', payload: wallet });
        
        // Generate mock transactions
        const transactions = generateMockTransactions(wallet.addresses[0].address);
        dispatch({ type: 'SET_TRANSACTIONS', payload: transactions });
        
        dispatch({ type: 'SET_LOADING', payload: false });
        return true;
      }
      dispatch({ type: 'SET_ERROR', payload: 'Invalid mnemonic phrase' });
      dispatch({ type: 'SET_LOADING', payload: false });
      return false;
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: 'Failed to import wallet' });
      dispatch({ type: 'SET_LOADING', payload: false });
      return false;
    }
  }, []);

  const lockWallet = useCallback(() => {
    dispatch({ type: 'LOCK_WALLET' });
  }, []);

  const unlockWallet = useCallback(() => {
    dispatch({ type: 'UNLOCK_WALLET' });
  }, []);

  const clearWallet = useCallback(() => {
    dispatch({ type: 'CLEAR_WALLET' });
  }, []);

  const updateBalance = useCallback((balance: number) => {
    dispatch({ type: 'SET_BALANCE', payload: balance });
  }, []);

  const setCurrency = useCallback((currencyCode: string) => {
    const currency = AFRICAN_CURRENCIES.find(c => c.code === currencyCode);
    if (currency) {
      dispatch({ 
        type: 'SET_SETTINGS', 
        payload: { ...state.settings, currency } 
      });
    }
  }, [state.settings]);

  const setLanguage = useCallback((language: UserSettings['language']) => {
    dispatch({ 
      type: 'SET_SETTINGS', 
      payload: { ...state.settings, language } 
    });
  }, [state.settings]);

  const setTheme = useCallback((theme: UserSettings['theme']) => {
    dispatch({ 
      type: 'SET_SETTINGS', 
      payload: { ...state.settings, theme } 
    });
  }, [state.settings]);

  const addHedgePosition = useCallback((position: HedgePosition) => {
    dispatch({ type: 'ADD_HEDGE_POSITION', payload: position });
  }, []);

  const updateHedgePosition = useCallback((position: HedgePosition) => {
    dispatch({ type: 'UPDATE_HEDGE_POSITION', payload: position });
  }, []);

  const addFarmPosition = useCallback((position: FarmPosition) => {
    dispatch({ type: 'ADD_FARM_POSITION', payload: position });
  }, []);

  const updateFarmPosition = useCallback((position: FarmPosition) => {
    dispatch({ type: 'UPDATE_FARM_POSITION', payload: position });
  }, []);

  const addTransaction = useCallback((transaction: Transaction) => {
    dispatch({ type: 'ADD_TRANSACTION', payload: transaction });
  }, []);

  const getBchBalance = useCallback((): number => {
    if (!state.wallet || state.wallet.addresses.length === 0) return 0;
    return state.wallet.addresses.reduce((sum, addr) => sum + addr.balance, 0) / 100000000;
  }, [state.wallet]);

  const getFiatBalance = useCallback((): number => {
    const bchBalance = getBchBalance();
    const bchPrice = state.tokens.find(t => t.symbol === 'BCH')?.price || 0;
    return bchBalance * bchPrice * state.settings.currency.rate;
  }, [getBchBalance, state.tokens, state.settings.currency.rate]);

  const value: WalletContextType = {
    state,
    createNewWallet,
    importExistingWallet,
    lockWallet,
    unlockWallet,
    clearWallet,
    updateBalance,
    setCurrency,
    setLanguage,
    setTheme,
    addHedgePosition,
    updateHedgePosition,
    addFarmPosition,
    updateFarmPosition,
    addTransaction,
    getBchBalance,
    getFiatBalance,
  };

  return (
    <WalletContext.Provider value={value}>
      {children}
    </WalletContext.Provider>
  );
}

// Hook to use wallet context
export function useWallet() {
  const context = useContext(WalletContext);
  if (context === undefined) {
    throw new Error('useWallet must be used within a WalletProvider');
  }
  return context;
}
