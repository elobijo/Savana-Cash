// Bitcoin Cash Wallet Types for Africa

export interface Wallet {
  id: string;
  name: string;
  mnemonic?: string;
  xpub?: string;
  addresses: WalletAddress[];
  createdAt: number;
  encrypted: boolean;
}

export interface WalletAddress {
  index: number;
  address: string;
  path: string;
  type: 'receiving' | 'change';
  balance: number;
  unconfirmedBalance: number;
}

export interface Transaction {
  id: string;
  txid: string;
  type: 'send' | 'receive' | 'swap' | 'hedge' | 'farm';
  amount: number;
  fee: number;
  confirmations: number;
  timestamp: number;
  address: string;
  status: 'pending' | 'confirmed' | 'failed';
  blockHeight?: number;
  token?: Token;
}

export interface Token {
  id: string;
  tokenId: string;
  symbol: string;
  name: string;
  decimals: number;
  icon: string;
  balance: number;
  price: number;
  change24h: number;
  category: 'fungible' | 'nft';
}

export interface SwapPair {
  from: Token;
  to: Token;
  rate: number;
  liquidity: number;
  volume24h: number;
  priceImpact: number;
}

export interface SwapOrder {
  id: string;
  fromToken: string;
  toToken: string;
  fromAmount: number;
  toAmount: number;
  rate: number;
  slippage: number;
  status: 'pending' | 'completed' | 'failed';
  timestamp: number;
}

export interface HedgePosition {
  id: string;
  type: 'long' | 'hedge';
  asset: string; // USD, GOLD, BTC, ETH
  leverage: number;
  bchAmount: number;
  startPrice: number;
  currentPrice: number;
  liquidationPrice: number;
  duration: number; // days
  startTime: number;
  endTime: number;
  status: 'active' | 'settled' | 'liquidated';
  pnl: number;
  pnlPercent: number;
}

export interface HedgeContract {
  id: string;
  position: HedgePosition;
  counterparty: string;
  oracle: string;
  settlementTxid?: string;
}

export interface FarmPool {
  id: string;
  name: string;
  token1: Token;
  token2: Token;
  tvl: number;
  apy: number;
  rewardToken: Token;
  rewardPerBlock: number;
  userStaked: number;
  userRewards: number;
}

export interface FarmPosition {
  id: string;
  pool: FarmPool;
  stakedAmount: number;
  rewardsEarned: number;
  startTime: number;
  lastClaimTime: number;
}

export interface PriceData {
  symbol: string;
  price: number;
  change24h: number;
  high24h: number;
  low24h: number;
  volume24h: number;
  marketCap: number;
  lastUpdated: number;
}

export interface CurrencyRate {
  code: string;
  name: string;
  symbol: string;
  rate: number; // Rate vs USD
  flag: string;
}

export interface UserSettings {
  currency: CurrencyRate;
  language: 'en' | 'sw' | 'fr' | 'zu';
  theme: 'light' | 'dark' | 'system';
  notifications: boolean;
  biometricLock: boolean;
  lowFeeMode: boolean;
}

export interface WalletState {
  wallet: Wallet | null;
  isLocked: boolean;
  transactions: Transaction[];
  tokens: Token[];
  hedgePositions: HedgePosition[];
  farmPositions: FarmPosition[];
  settings: UserSettings;
  isLoading: boolean;
  error: string | null;
}

// African Currencies
export const AFRICAN_CURRENCIES: CurrencyRate[] = [
  { code: 'USD', name: 'US Dollar', symbol: '$', rate: 1, flag: '🇺🇸' },
  { code: 'NGN', name: 'Nigerian Naira', symbol: '₦', rate: 1550, flag: '🇳🇬' },
  { code: 'ZAR', name: 'South African Rand', symbol: 'R', rate: 18.5, flag: '🇿🇦' },
  { code: 'KES', name: 'Kenyan Shilling', symbol: 'KSh', rate: 129, flag: '🇰🇪' },
  { code: 'GHS', name: 'Ghanaian Cedi', symbol: 'GH₵', rate: 15.2, flag: '🇬🇭' },
  { code: 'UGX', name: 'Ugandan Shilling', symbol: 'USh', rate: 3700, flag: '🇺🇬' },
  { code: 'TZS', name: 'Tanzanian Shilling', symbol: 'TSh', rate: 2500, flag: '🇹🇿' },
  { code: 'ZMW', name: 'Zambian Kwacha', symbol: 'ZK', rate: 25, flag: '🇿🇲' },
];

// Supported Hedge Assets
export const HEDGE_ASSETS = [
  { id: 'USD', name: 'US Dollar', symbol: 'USD', icon: '💵' },
  { id: 'GOLD', name: 'Gold', symbol: 'XAU', icon: '🥇' },
  { id: 'BTC', name: 'Bitcoin', symbol: 'BTC', icon: '₿' },
  { id: 'ETH', name: 'Ethereum', symbol: 'ETH', icon: 'Ξ' },
];

// Leverage Options
export const LEVERAGE_OPTIONS = [1, 2, 3, 4, 5];

// Duration Options (in days)
export const DURATION_OPTIONS = [7, 14, 30, 60, 90];
