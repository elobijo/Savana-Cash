// Wallet Utility Functions
// Note: In production, use proper cryptographic libraries like bch-js or bitcoinjs-lib

import { Wallet, WalletAddress, Transaction } from '@/types';

// Generate a random mnemonic (for demo purposes)
export function generateMnemonic(): string {
  const wordlist = [
    'abandon', 'ability', 'able', 'about', 'above', 'absent', 'absorb', 'abstract',
    'absurd', 'abuse', 'access', 'accident', 'account', 'accuse', 'achieve', 'acid',
    'acoustic', 'acquire', 'across', 'act', 'action', 'actor', 'actress', 'actual',
    'adapt', 'add', 'addict', 'address', 'adjust', 'admit', 'adult', 'advance',
    'advice', 'aerobic', 'affair', 'afford', 'afraid', 'again', 'age', 'agent',
    'agree', 'ahead', 'aim', 'air', 'airport', 'aisle', 'alarm', 'album',
    'alcohol', 'alert', 'alien', 'all', 'alley', 'allow', 'almost', 'alone',
    'alpha', 'already', 'also', 'alter', 'always', 'amateur', 'amazing', 'among',
    'amount', 'amused', 'analyst', 'anchor', 'ancient', 'anger', 'angle', 'angry',
    'animal', 'ankle', 'announce', 'annual', 'another', 'answer', 'antenna', 'antique',
    'anxiety', 'any', 'apart', 'apology', 'appear', 'apple', 'approve', 'april',
    'arch', 'arctic', 'area', 'arena', 'argue', 'arm', 'armed', 'armor',
    'army', 'around', 'arrange', 'arrest', 'arrive', 'arrow', 'art', 'artefact',
    'artist', 'artwork', 'ask', 'aspect', 'assault', 'asset', 'assist', 'assume',
    'asthma', 'athlete', 'atom', 'attack', 'attend', 'attitude', 'attract', 'auction',
    'audit', 'august', 'aunt', 'author', 'auto', 'autumn', 'average', 'avocado',
    'avoid', 'awake', 'aware', 'away', 'awesome', 'awful', 'awkward', 'axis',
    'baby', 'bachelor', 'bacon', 'badge', 'bag', 'balance', 'balcony', 'ball',
    'bamboo', 'banana', 'banner', 'bar', 'barely', 'bargain', 'barrel', 'base',
    'basic', 'basket', 'battle', 'beach', 'bean', 'beauty', 'because', 'become',
    'beef', 'before', 'begin', 'behave', 'behind', 'believe', 'below', 'belt',
    'bench', 'benefit', 'best', 'betray', 'better', 'between', 'beyond', 'bicycle',
    'bill', 'bird', 'birth', 'bitter', 'black', 'blade', 'blame', 'blanket',
    'blast', 'bleak', 'bless', 'blind', 'blood', 'blossom', 'blouse', 'blue',
    'blur', 'blush', 'board', 'boat', 'body', 'boil', 'bomb', 'bone',
    'bonus', 'book', 'boost', 'border', 'boring', 'borrow', 'boss', 'bottom',
    'bounce', 'box', 'boy', 'bracket', 'brain', 'brand', 'brass', 'brave',
    'bread', 'breeze', 'brick', 'bridge', 'brief', 'bright', 'bring', 'brisk',
    'broken', 'bronze', 'broom', 'brother', 'brown', 'brush', 'bubble', 'buddy',
    'budget', 'buffalo', 'build', 'bulb', 'bulk', 'bullet', 'bundle', 'bunker',
    'burden', 'burger', 'burst', 'bus', 'business', 'busy', 'butter', 'buyer',
    'buzz', 'cabbage', 'cabin', 'cable', 'cactus', 'cage', 'cake', 'call',
    'calm', 'camera', 'camp', 'canal', 'candy', 'cannon', 'canoe', 'canvas',
    'canyon', 'capable', 'capital', 'captain', 'car', 'carbon', 'card', 'cargo',
    'carpet', 'carry', 'cart', 'case', 'cash', 'casino', 'castle', 'casual',
  ];

  const words: string[] = [];
  for (let i = 0; i < 12; i++) {
    const randomIndex = Math.floor(Math.random() * wordlist.length);
    words.push(wordlist[randomIndex]);
  }
  return words.join(' ');
}

// Validate mnemonic
export function validateMnemonic(mnemonic: string): boolean {
  const words = mnemonic.trim().split(/\s+/);
  return words.length === 12 || words.length === 24;
}

// Generate a BCH address from seed (simplified for demo)
export function generateBchAddress(index: number, type: 'receiving' | 'change' = 'receiving'): string {
  // In production, derive from HD wallet (BIP32/BIP44)
  // Format: bitcoincash:qz...
  const chars = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l';
  let address = 'bitcoincash:q';
  for (let i = 0; i < 38; i++) {
    address += chars[Math.floor(Math.random() * chars.length)];
  }
  return address;
}

// Create a new wallet
export function createWallet(name: string = 'My BCH Wallet'): Wallet {
  const mnemonic = generateMnemonic();
  const addresses: WalletAddress[] = [];

  // Generate first 5 receiving addresses
  for (let i = 0; i < 5; i++) {
    addresses.push({
      index: i,
      address: generateBchAddress(i, 'receiving'),
      path: `m/44'/145'/0'/0/${i}`,
      type: 'receiving',
      balance: 0,
      unconfirmedBalance: 0,
    });
  }

  return {
    id: `wallet-${Date.now()}`,
    name,
    mnemonic,
    addresses,
    createdAt: Date.now(),
    encrypted: false,
  };
}

// Import wallet from mnemonic
export function importWallet(mnemonic: string, name: string = 'Imported Wallet'): Wallet | null {
  if (!validateMnemonic(mnemonic)) {
    return null;
  }

  const addresses: WalletAddress[] = [];
  for (let i = 0; i < 5; i++) {
    addresses.push({
      index: i,
      address: generateBchAddress(i, 'receiving'),
      path: `m/44'/145'/0'/0/${i}`,
      type: 'receiving',
      balance: 0,
      unconfirmedBalance: 0,
    });
  }

  return {
    id: `wallet-${Date.now()}`,
    name,
    mnemonic,
    addresses,
    createdAt: Date.now(),
    encrypted: false,
  };
}

// Format BCH amount
export function formatBch(satoshis: number): string {
  const bch = satoshis / 100000000;
  return bch.toLocaleString('en-US', { minimumFractionDigits: 8, maximumFractionDigits: 8 });
}

// Format fiat amount
export function formatFiat(amount: number, currency: string = 'USD'): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

// Convert BCH to fiat
export function bchToFiat(bchAmount: number, bchPrice: number, currencyRate: number = 1): number {
  return bchAmount * bchPrice * currencyRate;
}

// Generate mock transaction history
export function generateMockTransactions(address: string): Transaction[] {
  const transactions: Transaction[] = [];
  const types: Transaction['type'][] = ['send', 'receive', 'swap', 'hedge', 'farm'];

  for (let i = 0; i < 10; i++) {
    const type = types[Math.floor(Math.random() * types.length)];
    const amount = Math.random() * 5;
    const isReceive = type === 'receive' || Math.random() > 0.5;

    transactions.push({
      id: `tx-${Date.now()}-${i}`,
      txid: `${Date.now().toString(16)}${Math.random().toString(16).slice(2, 10)}`,
      type,
      amount: isReceive ? amount : -amount,
      fee: 0.00000141, // Very low BCH fees!
      confirmations: Math.floor(Math.random() * 10),
      timestamp: Date.now() - (i * 86400000 * Math.random()),
      address: isReceive ? address : generateBchAddress(i),
      status: Math.random() > 0.2 ? 'confirmed' : 'pending',
    });
  }

  return transactions.sort((a, b) => b.timestamp - a.timestamp);
}

// Shorten address for display
export function shortenAddress(address: string): string {
  if (address.startsWith('bitcoincash:')) {
    return `${address.slice(0, 12)}...${address.slice(-6)}`;
  }
  return `${address.slice(0, 8)}...${address.slice(-6)}`;
}

// Copy to clipboard
export async function copyToClipboard(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}

// Storage helpers
const WALLET_STORAGE_KEY = 'bch_wallet_data';
const SETTINGS_STORAGE_KEY = 'bch_wallet_settings';

export function saveWalletToStorage(wallet: Wallet): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(WALLET_STORAGE_KEY, JSON.stringify(wallet));
}

export function loadWalletFromStorage(): Wallet | null {
  if (typeof window === 'undefined') return null;
  const data = localStorage.getItem(WALLET_STORAGE_KEY);
  return data ? JSON.parse(data) : null;
}

export function clearWalletStorage(): void {
  if (typeof window === 'undefined') return;
  localStorage.removeItem(WALLET_STORAGE_KEY);
}

export function saveSettingsToStorage(settings: unknown): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
}

export function loadSettingsFromStorage(): unknown | null {
  if (typeof window === 'undefined') return null;
  const data = localStorage.getItem(SETTINGS_STORAGE_KEY);
  return data ? JSON.parse(data) : null;
}
