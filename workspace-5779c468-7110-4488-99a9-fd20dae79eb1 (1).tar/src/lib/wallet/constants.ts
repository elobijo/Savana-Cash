// BCH Wallet Constants

import { Token, CurrencyRate, FarmPool, PriceData } from '@/types';

// Network configuration
export const BCH_NETWORK = {
  mainnet: {
    genesisHash: '000000000019d6689c085ae165831e934ff763ae46a2a6c172b3f1b60a8ce26f',
    dustLimit: 546,
    minFee: 1,
    prefix: 'bitcoincash',
  },
  testnet: {
    genesisHash: '000000000933ea01ad0ee984209779baaec3ced90fa3f408719526f8d77f4943',
    dustLimit: 546,
    minFee: 1,
    prefix: 'bchtest',
  }
};

// Default tokens (CashTokens on BCH)
export const DEFAULT_TOKENS: Token[] = [
  {
    id: 'bch',
    tokenId: '0',
    symbol: 'BCH',
    name: 'Bitcoin Cash',
    decimals: 8,
    icon: '₿',
    balance: 0,
    price: 475.63,
    change24h: 2.34,
    category: 'fungible',
  },
  {
    id: 'flexusd',
    tokenId: 'cashtoken:flexusd',
    symbol: 'FLEXUSD',
    name: 'Flex USD',
    decimals: 8,
    icon: '💵',
    balance: 0,
    price: 1.0,
    change24h: 0.01,
    category: 'fungible',
  },
  {
    id: 'joy',
    tokenId: 'cashtoken:joy',
    symbol: 'JOY',
    name: 'Joy Token',
    decimals: 8,
    icon: '🎭',
    balance: 0,
    price: 0.045,
    change24h: 5.67,
    category: 'fungible',
  },
  {
    id: 'law',
    tokenId: 'cashtoken:law',
    symbol: 'LAW',
    name: 'Law Token',
    decimals: 8,
    icon: '⚖️',
    balance: 0,
    price: 0.12,
    change24h: -1.23,
    category: 'fungible',
  },
  {
    id: 'orbit',
    tokenId: 'cashtoken:orbit',
    symbol: 'ORBIT',
    name: 'Orbit Token',
    decimals: 8,
    icon: '🚀',
    balance: 0,
    price: 0.0089,
    change24h: 12.45,
    category: 'fungible',
  },
  {
    id: 'spice',
    tokenId: 'cashtoken:spice',
    symbol: 'SPICE',
    name: 'Spice Token',
    decimals: 8,
    icon: '🌶️',
    balance: 0,
    price: 0.023,
    change24h: 3.21,
    category: 'fungible',
  },
];

// Mock price data
export const MOCK_PRICES: Record<string, PriceData> = {
  BCH: {
    symbol: 'BCH',
    price: 475.63,
    change24h: 2.34,
    high24h: 485.20,
    low24h: 462.10,
    volume24h: 587658762,
    marketCap: 9345678901,
    lastUpdated: Date.now(),
  },
  FLEXUSD: {
    symbol: 'FLEXUSD',
    price: 1.0,
    change24h: 0.01,
    high24h: 1.001,
    low24h: 0.999,
    volume24h: 12345678,
    marketCap: 123456789,
    lastUpdated: Date.now(),
  },
  GOLD: {
    symbol: 'GOLD',
    price: 2025.50,
    change24h: 0.45,
    high24h: 2032.00,
    low24h: 2018.30,
    volume24h: 987654321,
    marketCap: 0,
    lastUpdated: Date.now(),
  },
  BTC: {
    symbol: 'BTC',
    price: 67250.00,
    change24h: 1.23,
    high24h: 68100.00,
    low24h: 66500.00,
    volume24h: 28987654321,
    marketCap: 1320000000000,
    lastUpdated: Date.now(),
  },
  ETH: {
    symbol: 'ETH',
    price: 3450.00,
    change24h: 1.87,
    high24h: 3520.00,
    low24h: 3380.00,
    volume24h: 15678912345,
    marketCap: 415000000000,
    lastUpdated: Date.now(),
  },
};

// Farm pools
export const DEFAULT_FARM_POOLS: FarmPool[] = [
  {
    id: 'pool-bch-flexusd',
    name: 'BCH-FLEXUSD',
    token1: DEFAULT_TOKENS[0],
    token2: DEFAULT_TOKENS[1],
    tvl: 1250000,
    apy: 45.5,
    rewardToken: DEFAULT_TOKENS[2],
    rewardPerBlock: 0.5,
    userStaked: 0,
    userRewards: 0,
  },
  {
    id: 'pool-bch-joy',
    name: 'BCH-JOY',
    token1: DEFAULT_TOKENS[0],
    token2: DEFAULT_TOKENS[2],
    tvl: 890000,
    apy: 78.2,
    rewardToken: DEFAULT_TOKENS[2],
    rewardPerBlock: 1.2,
    userStaked: 0,
    userRewards: 0,
  },
  {
    id: 'pool-bch-law',
    name: 'BCH-LAW',
    token1: DEFAULT_TOKENS[0],
    token2: DEFAULT_TOKENS[3],
    tvl: 520000,
    apy: 62.8,
    rewardToken: DEFAULT_TOKENS[3],
    rewardPerBlock: 0.8,
    userStaked: 0,
    userRewards: 0,
  },
  {
    id: 'pool-flexusd-joy',
    name: 'FLEXUSD-JOY',
    token1: DEFAULT_TOKENS[1],
    token2: DEFAULT_TOKENS[2],
    tvl: 340000,
    apy: 95.4,
    rewardToken: DEFAULT_TOKENS[2],
    rewardPerBlock: 2.5,
    userStaked: 0,
    userRewards: 0,
  },
];

// African country configurations
export const AFRICAN_CONFIG = {
  nigeria: {
    code: 'NG',
    name: 'Nigeria',
    currency: 'NGN',
    language: 'en',
    mobileMoney: ['Paga', 'OPay'],
    popularPairs: ['BCH/NGN', 'BCH/USDT'],
  },
  southAfrica: {
    code: 'ZA',
    name: 'South Africa',
    currency: 'ZAR',
    language: 'en',
    mobileMoney: ['M-Pesa', 'VodaPay'],
    popularPairs: ['BCH/ZAR', 'BCH/USDT'],
  },
  kenya: {
    code: 'KE',
    name: 'Kenya',
    currency: 'KES',
    language: 'sw',
    mobileMoney: ['M-Pesa', 'Airtel Money'],
    popularPairs: ['BCH/KES', 'BCH/USDT'],
  },
  ghana: {
    code: 'GH',
    name: 'Ghana',
    currency: 'GHS',
    language: 'en',
    mobileMoney: ['MTN Mobile Money', 'Vodafone Cash'],
    popularPairs: ['BCH/GHS', 'BCH/USDT'],
  },
};

// Transaction fee estimates (BCH has very low fees!)
export const FEE_ESTIMATES = {
  low: {
    satoshisPerByte: 1,
    estimatedFee: 141, // ~$0.0007
    confirmationTime: '10-20 minutes',
    label: 'Economy',
  },
  medium: {
    satoshisPerByte: 2,
    estimatedFee: 282, // ~$0.0014
    confirmationTime: '5-10 minutes',
    label: 'Standard',
  },
  high: {
    satoshisPerByte: 3,
    estimatedFee: 423, // ~$0.0021
    confirmationTime: '1-5 minutes',
    label: 'Priority',
  },
};

// Default user settings
export const DEFAULT_SETTINGS = {
  currency: {
    code: 'USD',
    name: 'US Dollar',
    symbol: '$',
    rate: 1,
    flag: '🇺🇸',
  },
  language: 'en' as const,
  theme: 'dark' as const,
  notifications: true,
  biometricLock: false,
  lowFeeMode: true,
};
