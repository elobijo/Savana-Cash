'use client';

import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ArrowDownUp, 
  Settings, 
  Info,
  RefreshCw,
  ChevronDown,
  Zap,
  AlertCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { useWallet } from '@/contexts/WalletContext';
import { DEFAULT_TOKENS } from '@/lib/wallet/constants';
import { formatFiat } from '@/lib/wallet/utils';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { Separator } from '@/components/ui/separator';
import { Token } from '@/types';

export function SwapInterface() {
  const { state, getBchBalance, addTransaction } = useWallet();
  const [fromToken, setFromToken] = useState<Token>(DEFAULT_TOKENS[0]); // BCH
  const [toToken, setToToken] = useState<Token>(DEFAULT_TOKENS[1]); // FLEXUSD
  const [fromAmount, setFromAmount] = useState('');
  const [slippage, setSlippage] = useState('0.5');
  const [showTokenSelector, setShowTokenSelector] = useState<'from' | 'to' | null>(null);
  const [isSwapping, setIsSwapping] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const bchBalance = getBchBalance();
  const tokens = DEFAULT_TOKENS;

  // Calculate exchange rate (mock)
  const getExchangeRate = (from: Token, to: Token): number => {
    if (from.symbol === 'BCH' && to.symbol === 'FLEXUSD') return 475;
    if (from.symbol === 'FLEXUSD' && to.symbol === 'BCH') return 1 / 475;
    if (from.symbol === 'BCH') return to.price / from.price;
    if (to.symbol === 'BCH') return from.price / to.price;
    return from.price / to.price;
  };

  const rate = getExchangeRate(fromToken, toToken);

  // Calculate to amount using useMemo instead of useEffect
  const toAmount = useMemo(() => {
    if (fromAmount) {
      const amount = parseFloat(fromAmount);
      if (!isNaN(amount)) {
        const calculated = amount * rate * (1 - parseFloat(slippage) / 100);
        return calculated.toFixed(toToken.decimals > 8 ? 8 : toToken.decimals);
      }
    }
    return '';
  }, [fromAmount, rate, slippage, toToken.decimals]);

  // Price impact calculation (mock)
  const getPriceImpact = (): number => {
    const amount = parseFloat(fromAmount) || 0;
    if (amount < 1) return 0.01;
    if (amount < 5) return 0.1;
    if (amount < 10) return 0.5;
    return 1.0;
  };

  const priceImpact = getPriceImpact();

  // Minimum received after slippage
  const minimumReceived = toAmount 
    ? (parseFloat(toAmount) * (1 - parseFloat(slippage) / 100)).toFixed(6)
    : '0';

  // Swap tokens
  const handleSwapTokens = () => {
    const temp = fromToken;
    setFromToken(toToken);
    setToToken(temp);
    setFromAmount(toAmount);
  };

  // Execute swap
  const handleSwap = async () => {
    if (!fromAmount || parseFloat(fromAmount) <= 0) return;
    
    setIsSwapping(true);
    
    // Simulate swap
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Add transaction
    addTransaction({
      id: `swap-${Date.now()}`,
      txid: `${Date.now().toString(16)}${Math.random().toString(16).slice(2, 10)}`,
      type: 'swap',
      amount: -parseFloat(fromAmount),
      fee: 0.00000141,
      confirmations: 0,
      timestamp: Date.now(),
      address: 'DEX Contract',
      status: 'pending',
    });

    setIsSwapping(false);
    setShowConfirm(false);
    setFromAmount('');
    setToAmount('');
  };

  // Get balance for token
  const getTokenBalance = (token: Token): number => {
    if (token.symbol === 'BCH') return bchBalance;
    return token.balance || 0;
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <Card className="bg-black/40 backdrop-blur border-amber-500/20">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-white">Swap Tokens</CardTitle>
              <CardDescription className="text-amber-200">
                Trade CashTokens instantly on BCH
              </CardDescription>
            </div>
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="ghost" size="icon" className="text-amber-400 hover:bg-amber-500/20">
                  <Settings className="h-4 w-4" />
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-gradient-to-br from-amber-950 to-orange-950 border-amber-500/30">
                <DialogHeader>
                  <DialogTitle className="text-white">Swap Settings</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 pt-4">
                  <div className="space-y-2">
                    <Label className="text-amber-100">Slippage Tolerance</Label>
                    <div className="flex gap-2">
                      {['0.1', '0.5', '1.0', '3.0'].map((s) => (
                        <Button
                          key={s}
                          variant={slippage === s ? 'default' : 'outline'}
                          size="sm"
                          onClick={() => setSlippage(s)}
                          className={slippage === s 
                            ? 'bg-amber-500 hover:bg-amber-600 text-white' 
                            : 'border-amber-500/30 text-amber-100 hover:bg-amber-500/20'
                          }
                        >
                          {s}%
                        </Button>
                      ))}
                      <Input
                        value={slippage}
                        onChange={(e) => setSlippage(e.target.value)}
                        className="w-20 bg-amber-900/30 border-amber-500/30 text-white"
                      />
                    </div>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Rate Info */}
          <div className="flex items-center justify-between bg-amber-900/30 rounded-lg px-3 py-2">
            <span className="text-amber-200 text-sm">Rate</span>
            <span className="text-white font-medium">
              1 {fromToken.symbol} = {rate.toFixed(6)} {toToken.symbol}
            </span>
          </div>

          {/* From Token */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <Label className="text-amber-100">From</Label>
              <button 
                onClick={() => setFromAmount(getTokenBalance(fromToken).toString())}
                className="text-amber-400 hover:text-amber-300"
              >
                Balance: {getTokenBalance(fromToken).toFixed(8)}
              </button>
            </div>
            <div className="flex gap-2">
              <div className="flex-1 relative">
                <Input
                  type="number"
                  value={fromAmount}
                  onChange={(e) => setFromAmount(e.target.value)}
                  placeholder="0.00"
                  className="bg-amber-900/30 border-amber-500/30 text-white text-lg h-14 placeholder:text-amber-200/50"
                />
              </div>
              <Sheet open={showTokenSelector === 'from'} onOpenChange={(open) => setShowTokenSelector(open ? 'from' : null)}>
                <SheetTrigger asChild>
                  <Button 
                    variant="outline" 
                    className="bg-amber-900/30 border-amber-500/30 text-white hover:bg-amber-800/40 h-14 px-4"
                  >
                    <span className="text-xl mr-2">{fromToken.icon}</span>
                    <span className="font-semibold">{fromToken.symbol}</span>
                    <ChevronDown className="h-4 w-4 ml-2" />
                  </Button>
                </SheetTrigger>
                <SheetContent className="bg-gradient-to-br from-amber-950 to-orange-950 border-amber-500/30">
                  <SheetHeader>
                    <SheetTitle className="text-white">Select Token</SheetTitle>
                    <SheetDescription className="text-amber-200">
                      Choose a token to swap from
                    </SheetDescription>
                  </SheetHeader>
                  <div className="space-y-2 mt-4">
                    {tokens.map((token) => (
                      <Button
                        key={token.id}
                        variant="ghost"
                        className="w-full justify-start bg-amber-900/20 hover:bg-amber-800/40 text-white"
                        onClick={() => {
                          setFromToken(token);
                          setShowTokenSelector(null);
                        }}
                      >
                        <span className="text-xl mr-3">{token.icon}</span>
                        <div className="text-left">
                          <p className="font-semibold">{token.symbol}</p>
                          <p className="text-xs text-amber-200">{token.name}</p>
                        </div>
                        <span className="ml-auto text-amber-200 text-sm">
                          {getTokenBalance(token).toFixed(4)}
                        </span>
                      </Button>
                    ))}
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>

          {/* Swap Direction Button */}
          <div className="flex justify-center">
            <Button
              variant="outline"
              size="icon"
              onClick={handleSwapTokens}
              className="bg-amber-900/40 border-amber-500/30 text-amber-400 hover:bg-amber-800/40 hover:text-amber-300 rounded-full h-10 w-10"
            >
              <ArrowDownUp className="h-4 w-4" />
            </Button>
          </div>

          {/* To Token */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <Label className="text-amber-100">To</Label>
              <span className="text-amber-200">
                Balance: {getTokenBalance(toToken).toFixed(8)}
              </span>
            </div>
            <div className="flex gap-2">
              <div className="flex-1">
                <Input
                  type="number"
                  value={toAmount}
                  readOnly
                  placeholder="0.00"
                  className="bg-amber-900/30 border-amber-500/30 text-white text-lg h-14 placeholder:text-amber-200/50"
                />
              </div>
              <Sheet open={showTokenSelector === 'to'} onOpenChange={(open) => setShowTokenSelector(open ? 'to' : null)}>
                <SheetTrigger asChild>
                  <Button 
                    variant="outline" 
                    className="bg-amber-900/30 border-amber-500/30 text-white hover:bg-amber-800/40 h-14 px-4"
                  >
                    <span className="text-xl mr-2">{toToken.icon}</span>
                    <span className="font-semibold">{toToken.symbol}</span>
                    <ChevronDown className="h-4 w-4 ml-2" />
                  </Button>
                </SheetTrigger>
                <SheetContent className="bg-gradient-to-br from-amber-950 to-orange-950 border-amber-500/30">
                  <SheetHeader>
                    <SheetTitle className="text-white">Select Token</SheetTitle>
                    <SheetDescription className="text-amber-200">
                      Choose a token to swap to
                    </SheetDescription>
                  </SheetHeader>
                  <div className="space-y-2 mt-4">
                    {tokens.filter(t => t.id !== fromToken.id).map((token) => (
                      <Button
                        key={token.id}
                        variant="ghost"
                        className="w-full justify-start bg-amber-900/20 hover:bg-amber-800/40 text-white"
                        onClick={() => {
                          setToToken(token);
                          setShowTokenSelector(null);
                        }}
                      >
                        <span className="text-xl mr-3">{token.icon}</span>
                        <div className="text-left">
                          <p className="font-semibold">{token.symbol}</p>
                          <p className="text-xs text-amber-200">{token.name}</p>
                        </div>
                      </Button>
                    ))}
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>

          {/* Swap Details */}
          {fromAmount && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="space-y-2 text-sm"
            >
              <div className="flex justify-between">
                <span className="text-amber-200">Price Impact</span>
                <span className={`font-medium ${priceImpact > 1 ? 'text-red-400' : 'text-white'}`}>
                  {priceImpact.toFixed(2)}%
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-amber-200">Minimum Received</span>
                <span className="text-white font-medium">
                  {minimumReceived} {toToken.symbol}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-amber-200">Slippage</span>
                <span className="text-white">{slippage}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-amber-200">Network Fee</span>
                <span className="text-white">~$0.001</span>
              </div>
            </motion.div>
          )}

          {/* Swap Button */}
          <Button
            onClick={() => setShowConfirm(true)}
            disabled={!fromAmount || parseFloat(fromAmount) <= 0 || parseFloat(fromAmount) > getTokenBalance(fromToken)}
            className="w-full bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-semibold py-6 text-lg disabled:opacity-50"
          >
            {!fromAmount 
              ? 'Enter an amount' 
              : parseFloat(fromAmount) > getTokenBalance(fromToken)
                ? 'Insufficient balance'
                : 'Swap'
            }
          </Button>
        </CardContent>
      </Card>

      {/* BCH Advantages */}
      <Card className="bg-gradient-to-br from-green-900/30 to-emerald-900/30 border-green-500/30">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Zap className="h-5 w-5 text-green-400 mt-0.5" />
            <div>
              <p className="text-green-100 font-medium">Why swap on BCH?</p>
              <p className="text-green-200/70 text-sm mt-1">
                Ultra-low fees (under $0.001), fast confirmations, and native CashToken support. 
                No gas wars, no failed transactions.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Confirm Dialog */}
      <Dialog open={showConfirm} onOpenChange={setShowConfirm}>
        <DialogContent className="bg-gradient-to-br from-amber-950 to-orange-950 border-amber-500/30">
          <DialogHeader>
            <DialogTitle className="text-white">Confirm Swap</DialogTitle>
            <DialogDescription className="text-amber-200">
              Review your swap details
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <div className="flex items-center justify-center gap-4 py-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-white">{fromAmount}</p>
                <p className="text-amber-200">{fromToken.symbol}</p>
              </div>
              <ArrowDownUp className="h-6 w-6 text-amber-400" />
              <div className="text-center">
                <p className="text-2xl font-bold text-white">{toAmount}</p>
                <p className="text-amber-200">{toToken.symbol}</p>
              </div>
            </div>
            
            <Separator className="bg-amber-500/20" />
            
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-amber-200">Rate</span>
                <span className="text-white">1 {fromToken.symbol} = {rate.toFixed(6)} {toToken.symbol}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-amber-200">Price Impact</span>
                <span className="text-white">{priceImpact.toFixed(2)}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-amber-200">Minimum Received</span>
                <span className="text-white">{minimumReceived} {toToken.symbol}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-amber-200">Network Fee</span>
                <span className="text-white">~$0.001</span>
              </div>
            </div>

            <div className="flex items-center gap-2 bg-amber-900/30 rounded-lg p-3">
              <AlertCircle className="h-4 w-4 text-amber-400" />
              <p className="text-xs text-amber-200">
                Output is estimated. You will receive at least {minimumReceived} {toToken.symbol} 
                or the transaction will revert.
              </p>
            </div>
            
            <Button
              onClick={handleSwap}
              disabled={isSwapping}
              className="w-full bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-semibold"
            >
              {isSwapping ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Swapping...
                </>
              ) : (
                'Confirm Swap'
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
