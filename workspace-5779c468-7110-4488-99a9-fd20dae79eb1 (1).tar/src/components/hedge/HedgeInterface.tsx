'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  TrendingUp, 
  TrendingDown, 
  Shield, 
  Info,
  AlertTriangle,
  Calculator,
  Clock,
  ChevronDown,
  Zap
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useWallet } from '@/contexts/WalletContext';
import { HEDGE_ASSETS, LEVERAGE_OPTIONS, DURATION_OPTIONS, HedgePosition } from '@/types';
import { MOCK_PRICES } from '@/lib/wallet/constants';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export function HedgeInterface() {
  const { state, getBchBalance, addHedgePosition } = useWallet();
  const [hedgeType, setHedgeType] = useState<'long' | 'hedge'>('long');
  const [selectedAsset, setSelectedAsset] = useState(HEDGE_ASSETS[0]);
  const [leverage, setLeverage] = useState(2);
  const [duration, setDuration] = useState(30);
  const [bchAmount, setBchAmount] = useState('');
  const [showConfirm, setShowConfirm] = useState(false);
  const [isCreating, setIsCreating] = useState(false);

  const bchBalance = getBchBalance();
  const bchPrice = MOCK_PRICES.BCH.price;
  const assetPrice = MOCK_PRICES[selectedAsset.id]?.price || 1;

  // Calculate position details
  const getPositionDetails = () => {
    const amount = parseFloat(bchAmount) || 0;
    const bchValueUsd = amount * bchPrice;
    const leverageMultiplier = hedgeType === 'long' ? leverage : 1;
    const hedgeMultiplier = hedgeType === 'hedge' ? leverage : 1;
    
    // Liquidation price calculation
    // For long: if price drops by (100 / leverage)%, position is liquidated
    // For hedge: if price rises by (100 / leverage)%, position is liquidated
    let liquidationPrice: number;
    if (hedgeType === 'long') {
      liquidationPrice = bchPrice * (1 - (1 / leverage) * 0.9);
    } else {
      liquidationPrice = bchPrice * (1 + (1 / leverage) * 0.9);
    }

    // Calculate settlement value in the hedged asset
    const settlementValue = hedgeType === 'long'
      ? (bchValueUsd * leverageMultiplier) / assetPrice  // Long BCH = leveraged exposure
      : bchValueUsd / assetPrice;  // Hedge = stable value in asset

    return {
      bchValueUsd,
      liquidationPrice,
      settlementValue,
      totalExposure: hedgeType === 'long' ? bchValueUsd * leverage : bchValueUsd,
    };
  };

  const details = getPositionDetails();

  // Active positions display
  const activePositions = state.hedgePositions.filter(p => p.status === 'active');

  // Create position
  const handleCreatePosition = async () => {
    if (!bchAmount || parseFloat(bchAmount) <= 0) return;

    setIsCreating(true);
    await new Promise(resolve => setTimeout(resolve, 2000));

    const position: HedgePosition = {
      id: `hedge-${Date.now()}`,
      type: hedgeType,
      asset: selectedAsset.id,
      leverage,
      bchAmount: parseFloat(bchAmount),
      startPrice: bchPrice,
      currentPrice: bchPrice,
      liquidationPrice: details.liquidationPrice,
      duration,
      startTime: Date.now(),
      endTime: Date.now() + duration * 24 * 60 * 60 * 1000,
      status: 'active',
      pnl: 0,
      pnlPercent: 0,
    };

    addHedgePosition(position);
    setIsCreating(false);
    setShowConfirm(false);
    setBchAmount('');
  };

  return (
    <div className="space-y-4">
      {/* Header Card */}
      <Card className="bg-black/40 backdrop-blur border-amber-500/20">
        <CardHeader className="pb-2">
          <CardTitle className="text-white flex items-center gap-2">
            <Shield className="h-5 w-5 text-amber-400" />
            Hedge & Leverage
          </CardTitle>
          <CardDescription className="text-amber-200">
            Protect against volatility or amplify your exposure
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Type Toggle */}
          <div className="flex gap-2">
            <Button
              variant={hedgeType === 'long' ? 'default' : 'outline'}
              onClick={() => setHedgeType('long')}
              className={`flex-1 py-6 ${
                hedgeType === 'long'
                  ? 'bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white'
                  : 'border-amber-500/30 text-amber-100 hover:bg-amber-500/20'
              }`}
            >
              <TrendingUp className="h-5 w-5 mr-2" />
              Long BCH
              <span className="ml-2 text-xs opacity-80">Up to 5x</span>
            </Button>
            <Button
              variant={hedgeType === 'hedge' ? 'default' : 'outline'}
              onClick={() => setHedgeType('hedge')}
              className={`flex-1 py-6 ${
                hedgeType === 'hedge'
                  ? 'bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white'
                  : 'border-amber-500/30 text-amber-100 hover:bg-amber-500/20'
              }`}
            >
              <Shield className="h-5 w-5 mr-2" />
              Hedge Value
              <span className="ml-2 text-xs opacity-80">Stable</span>
            </Button>
          </div>

          {/* Explanation */}
          <div className={`rounded-lg p-3 ${
            hedgeType === 'long' ? 'bg-green-900/30 border border-green-500/30' : 'bg-blue-900/30 border border-blue-500/30'
          }`}>
            <p className="text-sm text-white/80">
              {hedgeType === 'long' 
                ? '📈 Long BCH: Profit when BCH price increases. Use leverage to amplify gains (and risks).'
                : '🛡️ Hedge: Lock in the current USD value of your BCH. Protect against price drops.'
              }
            </p>
          </div>

          {/* Asset Selection */}
          <div className="space-y-2">
            <Label className="text-amber-100">
              {hedgeType === 'long' ? 'Long BCH against' : 'Hedge BCH value in'}
            </Label>
            <Select value={selectedAsset.id} onValueChange={(v) => setSelectedAsset(HEDGE_ASSETS.find(a => a.id === v) || HEDGE_ASSETS[0])}>
              <SelectTrigger className="bg-amber-900/30 border-amber-500/30 text-white h-14">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-amber-950 border-amber-500/30">
                {HEDGE_ASSETS.map((asset) => (
                  <SelectItem key={asset.id} value={asset.id} className="text-white hover:bg-amber-800/40">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{asset.icon}</span>
                      <div>
                        <p className="font-semibold">{asset.name}</p>
                        <p className="text-xs text-amber-200">${MOCK_PRICES[asset.id]?.price.toLocaleString() || '1.00'}</p>
                      </div>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Leverage Selection (for Long) */}
          {hedgeType === 'long' && (
            <div className="space-y-2">
              <Label className="text-amber-100">Leverage</Label>
              <div className="flex gap-2">
                {LEVERAGE_OPTIONS.map((l) => (
                  <Button
                    key={l}
                    variant={leverage === l ? 'default' : 'outline'}
                    onClick={() => setLeverage(l)}
                    className={`flex-1 ${
                      leverage === l
                        ? 'bg-amber-500 hover:bg-amber-600 text-white'
                        : 'border-amber-500/30 text-amber-100 hover:bg-amber-500/20'
                    }`}
                  >
                    {l}x
                  </Button>
                ))}
              </div>
            </div>
          )}

          {/* Duration Selection */}
          <div className="space-y-2">
            <Label className="text-amber-100">Duration</Label>
            <div className="flex gap-2 flex-wrap">
              {DURATION_OPTIONS.map((d) => (
                <Button
                  key={d}
                  variant={duration === d ? 'default' : 'outline'}
                  onClick={() => setDuration(d)}
                  className={`${
                    duration === d
                      ? 'bg-amber-500 hover:bg-amber-600 text-white'
                      : 'border-amber-500/30 text-amber-100 hover:bg-amber-500/20'
                  }`}
                >
                  {d} days
                </Button>
              ))}
            </div>
          </div>

          {/* Amount Input */}
          <div className="space-y-2">
            <div className="flex justify-between">
              <Label className="text-amber-100">BCH Amount</Label>
              <button
                onClick={() => setBchAmount(bchBalance.toString())}
                className="text-amber-400 hover:text-amber-300 text-sm"
              >
                Balance: {bchBalance.toFixed(8)} BCH
              </button>
            </div>
            <Input
              type="number"
              value={bchAmount}
              onChange={(e) => setBchAmount(e.target.value)}
              placeholder="0.00"
              className="bg-amber-900/30 border-amber-500/30 text-white text-lg h-14 placeholder:text-amber-200/50"
            />
          </div>

          {/* Position Details */}
          {bchAmount && parseFloat(bchAmount) > 0 && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="space-y-3 bg-amber-900/20 rounded-lg p-4 border border-amber-500/20"
            >
              <div className="flex items-center gap-2 text-amber-100 text-sm">
                <Calculator className="h-4 w-4" />
                <span className="font-medium">Position Details</span>
              </div>
              
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-amber-200">BCH Value</span>
                  <span className="text-white font-medium">
                    ${details.bchValueUsd.toFixed(2)} USD
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-amber-200">
                    {hedgeType === 'long' ? 'Total Exposure' : 'Hedged Value'}
                  </span>
                  <span className="text-white font-medium">
                    ${details.totalExposure.toFixed(2)} USD
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-amber-200">Liquidation Price</span>
                  <span className={`font-medium ${
                    hedgeType === 'long' ? 'text-red-400' : 'text-orange-400'
                  }`}>
                    ${details.liquidationPrice.toFixed(2)} / BCH
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-amber-200">Settlement In</span>
                  <span className="text-white font-medium">
                    {details.settlementValue.toFixed(4)} {selectedAsset.symbol}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <AlertTriangle className="h-4 w-4 text-amber-400" />
                <p className="text-xs text-amber-200">
                  {hedgeType === 'long'
                    ? `Position liquidates if BCH drops to $${details.liquidationPrice.toFixed(2)} (${((1 - details.liquidationPrice / bchPrice) * 100).toFixed(1)}% drop)`
                    : `Position settles at fixed ${selectedAsset.symbol} value regardless of BCH price`
                  }
                </p>
              </div>
            </motion.div>
          )}

          {/* Create Position Button */}
          <Button
            onClick={() => setShowConfirm(true)}
            disabled={!bchAmount || parseFloat(bchAmount) <= 0 || parseFloat(bchAmount) > bchBalance}
            className="w-full bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-semibold py-6 text-lg"
          >
            {!bchAmount
              ? 'Enter amount'
              : parseFloat(bchAmount) > bchBalance
                ? 'Insufficient balance'
                : hedgeType === 'long'
                  ? `Create ${leverage}x Long Position`
                  : 'Create Hedge Position'
            }
          </Button>
        </CardContent>
      </Card>

      {/* Active Positions */}
      {activePositions.length > 0 && (
        <Card className="bg-black/40 backdrop-blur border-amber-500/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-white text-lg">Active Positions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {activePositions.map((position) => (
                <motion.div
                  key={position.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="bg-amber-900/20 rounded-lg p-4 border border-amber-500/20"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Badge className={position.type === 'long' ? 'bg-green-500' : 'bg-blue-500'}>
                        {position.type === 'long' ? '📈 Long' : '🛡️ Hedge'}
                      </Badge>
                      <span className="text-white font-medium">
                        {position.type === 'long' ? `${position.leverage}x` : '1x'}
                      </span>
                    </div>
                    <Badge variant="outline" className="border-amber-500/30 text-amber-200">
                      <Clock className="h-3 w-3 mr-1" />
                      {Math.max(0, Math.ceil((position.endTime - Date.now()) / (24 * 60 * 60 * 1000)))}d left
                    </Badge>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-amber-200">{position.bchAmount.toFixed(4)} BCH</span>
                    <span className={position.pnl >= 0 ? 'text-green-400' : 'text-red-400'}>
                      {position.pnl >= 0 ? '+' : ''}{position.pnlPercent.toFixed(2)}%
                    </span>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Info Card */}
      <Card className="bg-gradient-to-br from-blue-900/30 to-indigo-900/30 border-blue-500/30">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Info className="h-5 w-5 text-blue-400 mt-0.5" />
            <div>
              <p className="text-blue-100 font-medium">How AnyHedge Works</p>
              <p className="text-blue-200/70 text-sm mt-1">
                AnyHedge is a peer-to-peer smart contract on BCH. No middlemen, no liquidations engine.
                Your position is fully collateralized and settled on-chain when the contract matures.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Confirm Dialog */}
      <Dialog open={showConfirm} onOpenChange={setShowConfirm}>
        <DialogContent className="bg-gradient-to-br from-amber-950 to-orange-950 border-amber-500/30">
          <DialogHeader>
            <DialogTitle className="text-white">
              Confirm {hedgeType === 'long' ? 'Long' : 'Hedge'} Position
            </DialogTitle>
            <DialogDescription className="text-amber-200">
              Review your contract details
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <div className="bg-amber-900/30 rounded-lg p-4 space-y-3">
              <div className="flex justify-between">
                <span className="text-amber-200">Type</span>
                <span className="text-white font-medium capitalize">{hedgeType} BCH</span>
              </div>
              <div className="flex justify-between">
                <span className="text-amber-200">Amount</span>
                <span className="text-white font-medium">{bchAmount} BCH</span>
              </div>
              {hedgeType === 'long' && (
                <div className="flex justify-between">
                  <span className="text-amber-200">Leverage</span>
                  <span className="text-white font-medium">{leverage}x</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-amber-200">Against</span>
                <span className="text-white font-medium">{selectedAsset.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-amber-200">Duration</span>
                <span className="text-white font-medium">{duration} days</span>
              </div>
              <div className="flex justify-between">
                <span className="text-amber-200">Liquidation</span>
                <span className="text-red-400 font-medium">${details.liquidationPrice.toFixed(2)}</span>
              </div>
            </div>

            <div className="flex items-center gap-2 bg-amber-900/20 rounded-lg p-3">
              <Zap className="h-4 w-4 text-amber-400" />
              <p className="text-xs text-amber-200">
                Smart contract fee: ~$0.01 • Settlement: On-chain at maturity
              </p>
            </div>
            
            <Button
              onClick={handleCreatePosition}
              disabled={isCreating}
              className="w-full bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-semibold"
            >
              {isCreating ? 'Creating Position...' : 'Create Position'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
