'use client';

import React from 'react';
import { 
  Settings, 
  Globe, 
  Moon, 
  Sun, 
  Bell, 
  Fingerprint, 
  Zap,
  LogOut,
  Trash2,
  Info,
  Shield,
  HelpCircle,
  ExternalLink,
  ChevronRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { useWallet } from '@/contexts/WalletContext';
import { AFRICAN_CURRENCIES, UserSettings } from '@/types';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

const LANGUAGES = [
  { code: 'en', name: 'English', flag: '🇬🇧' },
  { code: 'sw', name: 'Kiswahili', flag: '🇰🇪' },
  { code: 'fr', name: 'Français', flag: '🇫🇷' },
  { code: 'zu', name: 'isiZulu', flag: '🇿🇦' },
] as const;

export function SettingsView() {
  const { state, setCurrency, setLanguage, setTheme, clearWallet } = useWallet();
  const settings = state.settings;

  const handleLanguageChange = (lang: UserSettings['language']) => {
    setLanguage(lang);
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Header */}
      <Card className="bg-black/40 backdrop-blur border-amber-500/20">
        <CardHeader className="pb-2">
          <CardTitle className="text-white flex items-center gap-2">
            <Settings className="h-5 w-5 text-amber-400" />
            Settings
          </CardTitle>
          <CardDescription className="text-amber-200">
            Customize your wallet experience
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Currency */}
      <Card className="bg-black/40 backdrop-blur border-amber-500/20">
        <CardHeader className="pb-2">
          <CardTitle className="text-white text-base flex items-center gap-2">
            <Globe className="h-4 w-4 text-amber-400" />
            Currency & Region
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label className="text-amber-100">Display Currency</Label>
            <Select value={settings.currency.code} onValueChange={setCurrency}>
              <SelectTrigger className="bg-amber-900/30 border-amber-500/30 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-amber-950 border-amber-500/30">
                {AFRICAN_CURRENCIES.map((currency) => (
                  <SelectItem key={currency.code} value={currency.code} className="text-white hover:bg-amber-800/40">
                    <div className="flex items-center gap-2">
                      <span>{currency.flag}</span>
                      <span>{currency.symbol}</span>
                      <span>{currency.name}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label className="text-amber-100">Language</Label>
            <Select value={settings.language} onValueChange={handleLanguageChange}>
              <SelectTrigger className="bg-amber-900/30 border-amber-500/30 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-amber-950 border-amber-500/30">
                {LANGUAGES.map((lang) => (
                  <SelectItem key={lang.code} value={lang.code} className="text-white hover:bg-amber-800/40">
                    <div className="flex items-center gap-2">
                      <span>{lang.flag}</span>
                      <span>{lang.name}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Appearance */}
      <Card className="bg-black/40 backdrop-blur border-amber-500/20">
        <CardHeader className="pb-2">
          <CardTitle className="text-white text-base flex items-center gap-2">
            {settings.theme === 'dark' ? <Moon className="h-4 w-4 text-amber-400" /> : <Sun className="h-4 w-4 text-amber-400" />}
            Appearance
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-amber-100">Dark Mode</Label>
              <p className="text-xs text-amber-200/60">Optimized for battery saving</p>
            </div>
            <Switch
              checked={settings.theme === 'dark'}
              onCheckedChange={(checked) => setTheme(checked ? 'dark' : 'light')}
            />
          </div>
        </CardContent>
      </Card>

      {/* Security */}
      <Card className="bg-black/40 backdrop-blur border-amber-500/20">
        <CardHeader className="pb-2">
          <CardTitle className="text-white text-base flex items-center gap-2">
            <Shield className="h-4 w-4 text-amber-400" />
            Security
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-amber-100">Biometric Lock</Label>
              <p className="text-xs text-amber-200/60">Use fingerprint or face ID</p>
            </div>
            <Switch checked={settings.biometricLock} />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label className="text-amber-100">Notifications</Label>
              <p className="text-xs text-amber-200/60">Transaction alerts</p>
            </div>
            <Switch checked={settings.notifications} />
          </div>
        </CardContent>
      </Card>

      {/* Network */}
      <Card className="bg-black/40 backdrop-blur border-amber-500/20">
        <CardHeader className="pb-2">
          <CardTitle className="text-white text-base flex items-center gap-2">
            <Zap className="h-4 w-4 text-amber-400" />
            Network
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-amber-100">Low Fee Mode</Label>
              <p className="text-xs text-amber-200/60">Use minimum network fees</p>
            </div>
            <Switch checked={settings.lowFeeMode} />
          </div>

          <div className="bg-green-900/20 rounded-lg p-3 border border-green-500/20">
            <div className="flex items-center gap-2 text-green-400 text-sm">
              <Zap className="h-4 w-4" />
              <span>BCH Network Status</span>
            </div>
            <div className="mt-2 grid grid-cols-2 gap-2 text-xs">
              <div>
                <p className="text-green-200/60">Avg Fee</p>
                <p className="text-white font-medium">~$0.001</p>
              </div>
              <div>
                <p className="text-green-200/60">Block Time</p>
                <p className="text-white font-medium">~2 min</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* About */}
      <Card className="bg-black/40 backdrop-blur border-amber-500/20">
        <CardHeader className="pb-2">
          <CardTitle className="text-white text-base flex items-center gap-2">
            <Info className="h-4 w-4 text-amber-400" />
            About
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="w-full flex items-center justify-between p-3 rounded-lg bg-amber-900/20">
            <div className="flex items-center gap-3">
              <HelpCircle className="h-5 w-5 text-amber-400" />
              <span className="text-white">Help Center</span>
            </div>
            <ChevronRight className="h-4 w-4 text-amber-200/60" />
          </div>

          <div className="w-full flex items-center justify-between p-3 rounded-lg bg-amber-900/20">
            <div className="flex items-center gap-3">
              <ExternalLink className="h-5 w-5 text-amber-400" />
              <span className="text-white">Bitcoin Cash Website</span>
            </div>
            <ChevronRight className="h-4 w-4 text-amber-200/60" />
          </div>

          <div className="text-center py-4 text-sm text-amber-200/60">
            <p>Savanna Cash v1.0.0</p>
            <p className="mt-1">Built with love for Africa</p>
          </div>
        </CardContent>
      </Card>

      {/* Danger Zone */}
      <Card className="bg-red-900/20 border-red-500/30">
        <CardContent className="pt-4 space-y-3">
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" className="w-full">
                <LogOut className="h-4 w-4 mr-2" />
                Lock Wallet
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent className="bg-amber-950 border-amber-500/30">
              <AlertDialogHeader>
                <AlertDialogTitle className="text-white">Lock Wallet?</AlertDialogTitle>
                <AlertDialogDescription className="text-amber-200">
                  You will need to enter your password to unlock the wallet again.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel className="bg-amber-900/30 border-amber-500/30 text-white">Cancel</AlertDialogCancel>
                <AlertDialogAction className="bg-red-500 hover:bg-red-600">Lock</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>

          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="outline" className="w-full border-red-500/30 text-red-400 hover:bg-red-500/20">
                <Trash2 className="h-4 w-4 mr-2" />
                Delete Wallet
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent className="bg-amber-950 border-amber-500/30">
              <AlertDialogHeader>
                <AlertDialogTitle className="text-white">Delete Wallet?</AlertDialogTitle>
                <AlertDialogDescription className="text-amber-200">
                  This action cannot be undone. Make sure you have backed up your recovery phrase before deleting.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel className="bg-amber-900/30 border-amber-500/30 text-white">Cancel</AlertDialogCancel>
                <AlertDialogAction className="bg-red-500 hover:bg-red-600" onClick={clearWallet}>
                  Delete
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </CardContent>
      </Card>
    </div>
  );
}
