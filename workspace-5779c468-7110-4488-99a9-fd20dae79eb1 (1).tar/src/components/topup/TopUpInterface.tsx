'use client';

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  CreditCard, 
  Smartphone, 
  DollarSign,
  Check,
  Copy,
  ArrowRight,
  AlertCircle,
  Clock,
  Shield,
  Info
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useWallet } from '@/contexts/WalletContext';
import { AFRICAN_CURRENCIES } from '@/types';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

// Payment methods
const PAYMENT_METHODS = [
  {
    id: 'usdt',
    name: 'USDT (Tether)',
    icon: '💵',
    description: 'Stablecoin transfer via TRC20/BEP20',
    network: 'TRC20 / BEP20',
    minAmount: 10,
    maxAmount: 10000,
    fee: '0%',
    processingTime: '10-30 min',
    color: 'from-green-500 to-emerald-600',
    popular: true,
  },
  {
    id: 'mtn_momo',
    name: 'MTN Mobile Money',
    icon: '📱',
    description: 'Mobile money from MTN',
    network: 'Mobile',
    minAmount: 5,
    maxAmount: 5000,
    fee: '2%',
    processingTime: 'Instant',
    color: 'from-yellow-500 to-orange-600',
    popular: true,
    countries: ['GH', 'NG', 'UG', 'RW', 'CI', 'CM'],
  },
  {
    id: 'mpesa',
    name: 'M-Pesa',
    icon: '📲',
    description: 'Safaricom M-Pesa payment',
    network: 'Mobile',
    minAmount: 5,
    maxAmount: 3000,
    fee: '1.5%',
    processingTime: 'Instant',
    color: 'from-green-600 to-teal-600',
    popular: true,
    countries: ['KE', 'TZ', 'ZA', 'CD', 'GH', 'MW', 'MZ'],
  },
  {
    id: 'bank',
    name: 'Bank Transfer',
    icon: '🏦',
    description: 'Direct bank deposit',
    network: 'Bank',
    minAmount: 50,
    maxAmount: 50000,
    fee: '0%',
    processingTime: '1-3 days',
    color: 'from-blue-500 to-indigo-600',
    popular: false,
  },
];

// Country-specific payment details
const PAYMENT_DETAILS: Record<string, Record<string, { 
  accountName: string; 
  accountId: string; 
  instructions: string[];
}>> = {
  mtn_momo: {
    GH: {
      accountName: 'Savanna Cash',
      accountId: '024 XXX XXXX',
      instructions: [
        'Dial *170# on your MTN phone',
        'Select MoMo Pay & Merchants',
        'Enter merchant number: 024 XXX XXXX',
        'Enter amount and reference',
        'Confirm with your PIN',
      ],
    },
    NG: {
      accountName: 'Savanna Cash',
      accountId: '080 XXX XXXX',
      instructions: [
        'Dial *671# on your MTN line',
        'Select Send Money',
        'Enter recipient: 080 XXX XXXX',
        'Enter amount',
        'Confirm with your PIN',
      ],
    },
    UG: {
      accountName: 'Savanna Cash',
      accountId: '077 XXX XXXX',
      instructions: [
        'Dial *165# on your MTN phone',
        'Select Send Money',
        'Enter number: 077 XXX XXXX',
        'Enter amount and confirm',
      ],
    },
  },
  mpesa: {
    KE: {
      accountName: 'Savanna Cash',
      accountId: '07XX XXX XXX',
      instructions: [
        'Go to M-PESA on your phone',
        'Select Lipa na M-PESA',
        'Select Pay Bill',
        'Enter Business No: 07XX XXX XXX',
        'Enter Amount and PIN to confirm',
      ],
    },
    TZ: {
      accountName: 'Savanna Cash',
      accountId: '07XX XXX XXX',
      instructions: [
        'Dial *150*00# on your phone',
        'Select Send Money',
        'Enter number: 07XX XXX XXX',
        'Enter amount and confirm',
      ],
    },
  },
};

// USDT wallet addresses (demo)
const USDT_WALLETS = {
  TRC20: 'TJxas6Xw9YHn9z5Qw7ZxK3nVcR5tY2uM8P',
  BEP20: '0x742d35Cc6634C0532925a3b844Bc9e7595f',
};

export function TopUpInterface() {
  const { getBchBalance } = useWallet();
  const [selectedMethod, setSelectedMethod] = useState<typeof PAYMENT_METHODS[0] | null>(null);
  const [selectedCountry, setSelectedCountry] = useState('GH');
  const [amount, setAmount] = useState('');
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [copied, setCopied] = useState(false);

  const bchBalance = getBchBalance();
  const bchPrice = 475.63;

  const getBchEquivalent = (fiatAmount: number): number => {
    return fiatAmount / bchPrice;
  };

  const handleMethodSelect = (method: typeof PAYMENT_METHODS[0]) => {
    setSelectedMethod(method);
  };

  const handleContinue = () => {
    if (!amount || parseFloat(amount) <= 0) return;
    setShowPaymentDialog(true);
  };

  const handleCopy = async (text: string) => {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getPaymentDetails = () => {
    if (!selectedMethod) return null;
    if (selectedMethod.id === 'usdt') {
      return {
        accountName: 'USDT Wallet',
        accountId: USDT_WALLETS.TRC20,
        instructions: [
          `Send exactly $${amount} USDT to the address below`,
          'Network: TRC20 (Tron) or BEP20 (BSC)',
          'Copy the address and send from your wallet',
          'Your BCH will be credited after confirmation',
        ],
      };
    }
    return PAYMENT_DETAILS[selectedMethod.id]?.[selectedCountry] || null;
  };

  const paymentDetails = getPaymentDetails();

  return (
    <div className="space-y-4 pb-20">
      {/* Header */}
      <Card className="bg-black/40 backdrop-blur border-amber-500/20">
        <CardHeader className="pb-2">
          <CardTitle className="text-white flex items-center gap-2">
            <CreditCard className="h-5 w-5 text-amber-400" />
            Top Up Wallet
          </CardTitle>
          <CardDescription className="text-amber-200">
            Add BCH to your wallet using multiple payment methods
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Current Balance */}
      <Card className="bg-gradient-to-br from-amber-900/40 to-orange-900/40 border-amber-500/30">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-amber-200 text-sm">Current Balance</p>
              <p className="text-2xl font-bold text-white">{bchBalance.toFixed(8)} BCH</p>
              <p className="text-amber-200/60 text-sm">
                ≈ ${(bchBalance * bchPrice).toFixed(2)} USD
              </p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-orange-600 rounded-xl flex items-center justify-center">
              <span className="text-2xl">₿</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Payment Methods */}
      <Card className="bg-black/40 backdrop-blur border-amber-500/20">
        <CardHeader className="pb-2">
          <CardTitle className="text-white text-base">Select Payment Method</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {PAYMENT_METHODS.map((method) => (
              <motion.button
                key={method.id}
                whileHover={{ scale: 1.01 }}
                whileTap={{ scale: 0.99 }}
                onClick={() => handleMethodSelect(method)}
                className={`w-full p-4 rounded-xl border transition-all ${
                  selectedMethod?.id === method.id
                    ? 'border-amber-500 bg-amber-500/20'
                    : 'border-amber-500/20 bg-amber-900/20 hover:border-amber-500/40'
                }`}
              >
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${method.color} flex items-center justify-center text-2xl`}>
                    {method.icon}
                  </div>
                  <div className="flex-1 text-left">
                    <div className="flex items-center gap-2">
                      <p className="text-white font-semibold">{method.name}</p>
                      {method.popular && (
                        <Badge className="bg-green-500/20 text-green-400 border-0 text-xs">
                          Popular
                        </Badge>
                      )}
                    </div>
                    <p className="text-amber-200/60 text-sm">{method.description}</p>
                    <div className="flex items-center gap-4 mt-1 text-xs text-amber-200/60">
                      <span>Fee: {method.fee}</span>
                      <span>•</span>
                      <span>{method.processingTime}</span>
                    </div>
                  </div>
                  <ArrowRight className="h-5 w-5 text-amber-400" />
                </div>
              </motion.button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Amount Input */}
      {selectedMethod && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Card className="bg-black/40 backdrop-blur border-amber-500/20">
            <CardHeader className="pb-2">
              <CardTitle className="text-white text-base">Enter Amount</CardTitle>
              <CardDescription className="text-amber-200">
                Min: ${selectedMethod.minAmount} • Max: ${selectedMethod.maxAmount.toLocaleString()}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Quick Amount Buttons */}
              <div className="flex gap-2 flex-wrap">
                {[10, 25, 50, 100, 250].map((quickAmount) => (
                  <Button
                    key={quickAmount}
                    variant="outline"
                    size="sm"
                    onClick={() => setAmount(quickAmount.toString())}
                    className={`${
                      amount === quickAmount.toString()
                        ? 'bg-amber-500 text-white border-amber-500'
                        : 'border-amber-500/30 text-amber-100 hover:bg-amber-500/20'
                    }`}
                  >
                    ${quickAmount}
                  </Button>
                ))}
              </div>

              {/* Amount Input */}
              <div className="space-y-2">
                <Label className="text-amber-100">Amount (USD)</Label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-amber-400" />
                  <Input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="0.00"
                    className="bg-amber-900/30 border-amber-500/30 text-white text-lg h-14 pl-10 placeholder:text-amber-200/50"
                  />
                </div>
              </div>

              {/* BCH Equivalent */}
              {amount && parseFloat(amount) > 0 && (
                <div className="bg-amber-900/30 rounded-lg p-4 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-amber-200">You&apos;ll receive</span>
                    <span className="text-white font-semibold">
                      {getBchEquivalent(parseFloat(amount)).toFixed(8)} BCH
                    </span>
                  </div>
                  {selectedMethod.fee !== '0%' && (
                    <div className="flex justify-between text-sm">
                      <span className="text-amber-200">Fee ({selectedMethod.fee})</span>
                      <span className="text-amber-100">
                        ${(parseFloat(amount) * parseFloat(selectedMethod.fee) / 100).toFixed(2)}
                      </span>
                    </div>
                  )}
                </div>
              )}

              {/* Country Selection for Mobile Money */}
              {(selectedMethod.id === 'mtn_momo' || selectedMethod.id === 'mpesa') && (
                <div className="space-y-2">
                  <Label className="text-amber-100">Your Country</Label>
                  <Select value={selectedCountry} onValueChange={setSelectedCountry}>
                    <SelectTrigger className="bg-amber-900/30 border-amber-500/30 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-amber-950 border-amber-500/30">
                      {AFRICAN_CURRENCIES.map((currency) => (
                        <SelectItem key={currency.code} value={currency.code} className="text-white">
                          {currency.flag} {currency.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <Button
                onClick={handleContinue}
                disabled={!amount || parseFloat(amount) < selectedMethod.minAmount || parseFloat(amount) > selectedMethod.maxAmount}
                className="w-full bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-semibold py-6"
              >
                Continue
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Payment Dialog */}
      <Dialog open={showPaymentDialog} onOpenChange={setShowPaymentDialog}>
        <DialogContent className="bg-gradient-to-br from-amber-950 to-orange-950 border-amber-500/30 max-w-md">
          <DialogHeader>
            <DialogTitle className="text-white">
              {selectedMethod?.id === 'usdt' ? 'Send USDT' : `Pay via ${selectedMethod?.name}`}
            </DialogTitle>
            <DialogDescription className="text-amber-200">
              Follow the instructions below to complete your payment
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 pt-4">
            {/* Amount Summary */}
            <div className="bg-amber-900/30 rounded-lg p-4 text-center">
              <p className="text-amber-200 text-sm">Amount to Pay</p>
              <p className="text-3xl font-bold text-white">${amount}</p>
              <p className="text-amber-200/60 text-sm mt-1">
                = {getBchEquivalent(parseFloat(amount || '0')).toFixed(8)} BCH
              </p>
            </div>

            {/* USDT Payment */}
            {selectedMethod?.id === 'usdt' && (
              <div className="space-y-4">
                <div className="bg-amber-900/20 rounded-lg p-4 space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-amber-200 text-sm">Network</span>
                    <Badge className="bg-green-500/20 text-green-400 border-0">TRC20</Badge>
                  </div>
                  <div>
                    <p className="text-amber-200 text-sm mb-1">USDT Address</p>
                    <div className="flex items-center gap-2">
                      <code className="flex-1 text-xs text-white bg-black/30 p-2 rounded break-all">
                        {USDT_WALLETS.TRC20}
                      </code>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleCopy(USDT_WALLETS.TRC20)}
                        className="text-amber-400 hover:bg-amber-500/20 shrink-0"
                      >
                        {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>
                </div>

                {/* QR Code */}
                <div className="flex justify-center">
                  <div className="bg-white p-3 rounded-xl">
                    <img 
                      src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${USDT_WALLETS.TRC20}`}
                      alt="USDT Address QR"
                      className="w-36 h-36"
                    />
                  </div>
                </div>

                <div className="bg-red-900/20 border border-red-500/30 rounded-lg p-3">
                  <div className="flex items-start gap-2">
                    <AlertCircle className="h-4 w-4 text-red-400 mt-0.5 shrink-0" />
                    <div className="text-sm text-red-200">
                      <p className="font-medium">Important</p>
                      <p className="mt-1">Send only USDT (TRC20) to this address. Other tokens may be lost.</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Mobile Money Payment */}
            {(selectedMethod?.id === 'mtn_momo' || selectedMethod?.id === 'mpesa') && paymentDetails && (
              <div className="space-y-4">
                <div className="bg-amber-900/20 rounded-lg p-4 space-y-3">
                  <div className="flex justify-between">
                    <span className="text-amber-200">Account Name</span>
                    <span className="text-white font-medium">{paymentDetails.accountName}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-amber-200">
                      {selectedMethod.id === 'mpesa' ? 'Paybill/Till' : 'Number'}
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="text-white font-medium">{paymentDetails.accountId}</span>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleCopy(paymentDetails.accountId)}
                        className="text-amber-400 hover:bg-amber-500/20 h-6 w-6"
                      >
                        {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Instructions */}
                <div className="space-y-2">
                  <p className="text-amber-200 text-sm font-medium">Instructions</p>
                  <div className="space-y-2">
                    {paymentDetails.instructions.map((instruction, index) => (
                      <div key={index} className="flex items-start gap-3 bg-amber-900/20 rounded-lg p-3">
                        <div className="w-6 h-6 bg-amber-500 rounded-full flex items-center justify-center text-white text-sm font-medium shrink-0">
                          {index + 1}
                        </div>
                        <p className="text-amber-100 text-sm">{instruction}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            <Separator className="bg-amber-500/20" />

            {/* Processing Info */}
            <div className="flex items-center gap-2 text-amber-200">
              <Clock className="h-4 w-4" />
              <span className="text-sm">Processing time: {selectedMethod?.processingTime}</span>
            </div>

            <div className="flex items-center gap-2 text-amber-200">
              <Shield className="h-4 w-4" />
              <span className="text-sm">Secure payment - Powered by Savanna Cash</span>
            </div>

            <Button
              onClick={() => {
                setShowPaymentDialog(false);
                setAmount('');
                setSelectedMethod(null);
              }}
              className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white font-semibold"
            >
              <Check className="mr-2 h-4 w-4" />
              I&apos;ve Made the Payment
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Info Card */}
      <Card className="bg-gradient-to-br from-blue-900/30 to-indigo-900/30 border-blue-500/30">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Info className="h-5 w-5 text-blue-400 mt-0.5" />
            <div>
              <p className="text-blue-100 font-medium">How Top Up Works</p>
              <p className="text-blue-200/70 text-sm mt-1">
                Select a payment method, enter the amount, and follow the payment instructions. 
                Your BCH will be credited to your wallet after confirmation. 
                All transactions are processed securely.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
