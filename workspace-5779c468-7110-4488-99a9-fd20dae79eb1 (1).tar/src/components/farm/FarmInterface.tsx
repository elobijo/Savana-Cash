'use client';

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Droplets, 
  TrendingUp, 
  Coins, 
  Info,
  Plus,
  Minus,
  Gift,
  Timer,
  BarChart3,
  AlertCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { useWallet } from '@/contexts/WalletContext';
import { DEFAULT_FARM_POOLS } from '@/lib/wallet/constants';
import { formatFiat } from '@/lib/wallet/utils';
import { FarmPool, FarmPosition } from '@/types';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

export function FarmInterface() {
  const { state, getBchBalance, addFarmPosition, updateFarmPosition } = useWallet();
  const [selectedPool, setSelectedPool] = useState<FarmPool | null>(null);
  const [stakeAmount, setStakeAmount] = useState('');
  const [showStakeDialog, setShowStakeDialog] = useState(false);
  const [showUnstakeDialog, setShowUnstakeDialog] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  const bchBalance = getBchBalance();
  const pools = DEFAULT_FARM_POOLS;

  // Total staked value
  const totalStaked = state.farmPositions.reduce((sum, pos) => sum + pos.stakedAmount, 0);
  const totalRewards = state.farmPositions.reduce((sum, pos) => sum + pos.rewardsEarned, 0);

  // Handle stake
  const handleStake = async () => {
    if (!selectedPool || !stakeAmount || parseFloat(stakeAmount) <= 0) return;

    setIsProcessing(true);
    await new Promise(resolve => setTimeout(resolve, 2000));

    const existingPosition = state.farmPositions.find(p => p.pool.id === selectedPool.id);
    
    if (existingPosition) {
      updateFarmPosition({
        ...existingPosition,
        stakedAmount: existingPosition.stakedAmount + parseFloat(stakeAmount),
      });
    } else {
      const position: FarmPosition = {
        id: `farm-${Date.now()}`,
        pool: selectedPool,
        stakedAmount: parseFloat(stakeAmount),
        rewardsEarned: 0,
        startTime: Date.now(),
        lastClaimTime: Date.now(),
      };
      addFarmPosition(position);
    }

    setIsProcessing(false);
    setShowStakeDialog(false);
    setStakeAmount('');
  };

  // Handle unstake
  const handleUnstake = async () => {
    if (!selectedPool || !stakeAmount) return;

    setIsProcessing(true);
    await new Promise(resolve => setTimeout(resolve, 2000));

    const position = state.farmPositions.find(p => p.pool.id === selectedPool.id);
    if (position) {
      const newAmount = Math.max(0, position.stakedAmount - parseFloat(stakeAmount));
      if (newAmount === 0) {
        // Remove position if fully unstaked
        updateFarmPosition({ ...position, stakedAmount: 0 });
      } else {
        updateFarmPosition({ ...position, stakedAmount: newAmount });
      }
    }

    setIsProcessing(false);
    setShowUnstakeDialog(false);
    setStakeAmount('');
  };

  // Handle claim rewards
  const handleClaimRewards = async (poolId: string) => {
    const position = state.farmPositions.find(p => p.pool.id === poolId);
    if (position && position.rewardsEarned > 0) {
      updateFarmPosition({
        ...position,
        rewardsEarned: 0,
        lastClaimTime: Date.now(),
      });
    }
  };

  // Get user position for pool
  const getUserPosition = (poolId: string) => {
    return state.farmPositions.find(p => p.pool.id === poolId);
  };

  return (
    <div className="space-y-4">
      {/* Stats Overview */}
      <div className="grid grid-cols-2 gap-3">
        <Card className="bg-gradient-to-br from-green-900/40 to-emerald-900/40 border-green-500/30">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-1">
              <Droplets className="h-4 w-4 text-green-400" />
              <span className="text-green-200 text-sm">Total Staked</span>
            </div>
            <p className="text-2xl font-bold text-white">{totalStaked.toFixed(4)}</p>
            <p className="text-green-200/60 text-sm">BCH equivalent</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-amber-900/40 to-orange-900/40 border-amber-500/30">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-1">
              <Gift className="h-4 w-4 text-amber-400" />
              <span className="text-amber-200 text-sm">Rewards</span>
            </div>
            <p className="text-2xl font-bold text-white">{totalRewards.toFixed(4)}</p>
            <p className="text-amber-200/60 text-sm">Tokens earned</p>
          </CardContent>
        </Card>
      </div>

      {/* Farm Pools */}
      <Card className="bg-black/40 backdrop-blur border-amber-500/20">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-white flex items-center gap-2">
                <Droplets className="h-5 w-5 text-amber-400" />
                Liquidity Pools
              </CardTitle>
              <CardDescription className="text-amber-200">
                Stake tokens to earn yield
              </CardDescription>
            </div>
            <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
              <TrendingUp className="h-3 w-3 mr-1" />
              Live
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {pools.map((pool, index) => {
              const userPosition = getUserPosition(pool.id);
              const hasPosition = userPosition && userPosition.stakedAmount > 0;

              return (
                <motion.div
                  key={pool.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-amber-900/20 rounded-xl p-4 border border-amber-500/20 hover:border-amber-500/40 transition-colors"
                >
                  {/* Pool Header */}
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="flex -space-x-2">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center text-white font-bold border-2 border-amber-950">
                          {pool.token1.icon}
                        </div>
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white font-bold border-2 border-amber-950">
                          {pool.token2.icon}
                        </div>
                      </div>
                      <div>
                        <p className="text-white font-semibold">{pool.name}</p>
                        <p className="text-amber-200/60 text-sm">BCH LP Token</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-lg px-3 py-1">
                        {pool.apy}% APY
                      </Badge>
                    </div>
                  </div>

                  {/* Pool Stats */}
                  <div className="grid grid-cols-3 gap-4 mb-4">
                    <div>
                      <p className="text-amber-200/60 text-xs">TVL</p>
                      <p className="text-white font-medium">{formatFiat(pool.tvl)}</p>
                    </div>
                    <div>
                      <p className="text-amber-200/60 text-xs">Reward</p>
                      <p className="text-white font-medium">{pool.rewardToken.symbol}</p>
                    </div>
                    <div>
                      <p className="text-amber-200/60 text-xs">Per Block</p>
                      <p className="text-white font-medium">{pool.rewardPerBlock}</p>
                    </div>
                  </div>

                  {/* User Position */}
                  {hasPosition && (
                    <div className="bg-green-900/20 rounded-lg p-3 mb-3 border border-green-500/20">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-green-200 text-sm">Your Position</span>
                        <Badge variant="outline" className="border-green-500/30 text-green-400">
                          Active
                        </Badge>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-green-200">Staked: {userPosition.stakedAmount.toFixed(4)}</span>
                        <span className="text-amber-400">+{userPosition.rewardsEarned.toFixed(4)} {pool.rewardToken.symbol}</span>
                      </div>
                      <Progress value={userPosition.rewardsEarned * 10} className="h-1.5 mt-2 bg-green-900/50" />
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex gap-2">
                    <Button
                      onClick={() => {
                        setSelectedPool(pool);
                        setShowStakeDialog(true);
                      }}
                      className="flex-1 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white"
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      Stake
                    </Button>
                    {hasPosition && (
                      <>
                        <Button
                          variant="outline"
                          onClick={() => {
                            setSelectedPool(pool);
                            setStakeAmount(userPosition.stakedAmount.toString());
                            setShowUnstakeDialog(true);
                          }}
                          className="border-amber-500/30 text-amber-100 hover:bg-amber-500/20"
                        >
                          <Minus className="h-4 w-4 mr-1" />
                          Unstake
                        </Button>
                        <Button
                          variant="outline"
                          onClick={() => handleClaimRewards(pool.id)}
                          disabled={userPosition.rewardsEarned <= 0}
                          className="border-green-500/30 text-green-400 hover:bg-green-500/20 disabled:opacity-50"
                        >
                          <Gift className="h-4 w-4 mr-1" />
                          Claim
                        </Button>
                      </>
                    )}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Info Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <Card className="bg-gradient-to-br from-purple-900/30 to-indigo-900/30 border-purple-500/30">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <BarChart3 className="h-5 w-5 text-purple-400 mt-0.5" />
              <div>
                <p className="text-purple-100 font-medium">How Yield Farming Works</p>
                <p className="text-purple-200/70 text-sm mt-1">
                  Provide liquidity to DEX pools and earn trading fees plus reward tokens. 
                  Higher APY = higher risk.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-cyan-900/30 to-blue-900/30 border-cyan-500/30">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <Info className="h-5 w-5 text-cyan-400 mt-0.5" />
              <div>
                <p className="text-cyan-100 font-medium">Impermanent Loss</p>
                <p className="text-cyan-200/70 text-sm mt-1">
                  When prices diverge, you may have less value than just holding. 
                  Consider stable pairs for lower risk.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Stake Dialog */}
      <Dialog open={showStakeDialog} onOpenChange={setShowStakeDialog}>
        <DialogContent className="bg-gradient-to-br from-amber-950 to-orange-950 border-amber-500/30">
          <DialogHeader>
            <DialogTitle className="text-white">Stake in {selectedPool?.name}</DialogTitle>
            <DialogDescription className="text-amber-200">
              Add liquidity to earn {selectedPool?.apy}% APY
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <div className="space-y-2">
              <div className="flex justify-between">
                <Label className="text-amber-100">Amount (BCH)</Label>
                <button
                  onClick={() => setStakeAmount(bchBalance.toString())}
                  className="text-amber-400 hover:text-amber-300 text-sm"
                >
                  Max: {bchBalance.toFixed(8)}
                </button>
              </div>
              <Input
                type="number"
                value={stakeAmount}
                onChange={(e) => setStakeAmount(e.target.value)}
                placeholder="0.00"
                className="bg-amber-900/30 border-amber-500/30 text-white text-lg h-14 placeholder:text-amber-200/50"
              />
            </div>

            <div className="bg-amber-900/20 rounded-lg p-3 space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-amber-200">Pool APY</span>
                <span className="text-green-400 font-medium">{selectedPool?.apy}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-amber-200">Daily Yield</span>
                <span className="text-white">
                  {stakeAmount ? ((parseFloat(stakeAmount) * (selectedPool?.apy || 0) / 100) / 365).toFixed(8) : '0'} BCH
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-amber-200">Network Fee</span>
                <span className="text-white">~$0.001</span>
              </div>
            </div>

            <div className="flex items-center gap-2 bg-amber-900/30 rounded-lg p-3">
              <AlertCircle className="h-4 w-4 text-amber-400" />
              <p className="text-xs text-amber-200">
                You'll receive LP tokens representing your share of the pool
              </p>
            </div>
            
            <Button
              onClick={handleStake}
              disabled={isProcessing || !stakeAmount || parseFloat(stakeAmount) <= 0}
              className="w-full bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-semibold"
            >
              {isProcessing ? 'Staking...' : 'Stake'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Unstake Dialog */}
      <Dialog open={showUnstakeDialog} onOpenChange={setShowUnstakeDialog}>
        <DialogContent className="bg-gradient-to-br from-amber-950 to-orange-950 border-amber-500/30">
          <DialogHeader>
            <DialogTitle className="text-white">Unstake from {selectedPool?.name}</DialogTitle>
            <DialogDescription className="text-amber-200">
              Remove your liquidity from the pool
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <div className="space-y-2">
              <div className="flex justify-between">
                <Label className="text-amber-100">Amount to Unstake</Label>
                <button
                  onClick={() => {
                    const pos = getUserPosition(selectedPool?.id || '');
                    if (pos) setStakeAmount(pos.stakedAmount.toString());
                  }}
                  className="text-amber-400 hover:text-amber-300 text-sm"
                >
                  Max: {getUserPosition(selectedPool?.id || '')?.stakedAmount.toFixed(8) || '0'}
                </button>
              </div>
              <Input
                type="number"
                value={stakeAmount}
                onChange={(e) => setStakeAmount(e.target.value)}
                placeholder="0.00"
                className="bg-amber-900/30 border-amber-500/30 text-white text-lg h-14 placeholder:text-amber-200/50"
              />
            </div>

            <div className="bg-amber-900/20 rounded-lg p-3 space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-amber-200">Unstaked Amount</span>
                <span className="text-white">{stakeAmount || '0'} BCH</span>
              </div>
              <div className="flex justify-between">
                <span className="text-amber-200">Network Fee</span>
                <span className="text-white">~$0.001</span>
              </div>
            </div>
            
            <Button
              onClick={handleUnstake}
              disabled={isProcessing || !stakeAmount || parseFloat(stakeAmount) <= 0}
              className="w-full bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-semibold"
            >
              {isProcessing ? 'Unstaking...' : 'Unstake'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
