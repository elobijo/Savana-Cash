'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { 
  Wallet, 
  ArrowDownUp, 
  Shield, 
  Droplets, 
  Settings,
  PlusCircle
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface BottomNavProps {
  activeView: string;
  onViewChange: (view: string) => void;
}

const navItems = [
  { id: 'wallet', label: 'Wallet', icon: Wallet },
  { id: 'topup', label: 'Top Up', icon: PlusCircle },
  { id: 'swap', label: 'Swap', icon: ArrowDownUp },
  { id: 'hedge', label: 'Hedge', icon: Shield },
  { id: 'farm', label: 'Farm', icon: Droplets },
];

export function BottomNav({ activeView, onViewChange }: BottomNavProps) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-gradient-to-t from-amber-950 via-amber-950/98 to-amber-950/95 backdrop-blur-lg border-t border-amber-500/20 safe-area-bottom">
      <div className="max-w-lg mx-auto px-2">
        <div className="flex items-center justify-around py-2">
          {navItems.map((item) => {
            const isActive = activeView === item.id;
            const Icon = item.icon;
            
            return (
              <button
                key={item.id}
                onClick={() => onViewChange(item.id)}
                className={cn(
                  "relative flex flex-col items-center justify-center py-2 px-3 rounded-xl transition-all duration-200 min-w-[60px]",
                  isActive ? "text-amber-400" : "text-amber-200/60 hover:text-amber-200"
                )}
              >
                {isActive && (
                  <motion.div
                    layoutId="activeTab"
                    className="absolute inset-0 bg-amber-500/20 rounded-xl"
                    initial={false}
                    transition={{ type: "spring", stiffness: 500, damping: 30 }}
                  />
                )}
                <Icon className={cn(
                  "h-5 w-5 mb-1 relative z-10 transition-transform",
                  isActive && "scale-110"
                )} />
                <span className={cn(
                  "text-xs font-medium relative z-10",
                  isActive && "font-semibold"
                )}>
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
}

export function TopBar({ onSettingsClick }: { onSettingsClick?: () => void }) {
  return (
    <header className="sticky top-0 z-40 bg-gradient-to-b from-amber-950 to-amber-950/95 backdrop-blur-lg border-b border-amber-500/20">
      <div className="max-w-lg mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-br from-amber-400 to-orange-600 rounded-lg flex items-center justify-center shadow-lg">
            <span className="text-lg font-bold text-white">₿</span>
          </div>
          <div>
            <h1 className="text-lg font-bold text-white">Savanna Cash</h1>
            <p className="text-xs text-amber-200/60">Bitcoin Cash for Africa</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 bg-green-500/20 rounded-full px-3 py-1">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            <span className="text-xs text-green-400">Mainnet</span>
          </div>
          {onSettingsClick && (
            <button
              onClick={onSettingsClick}
              className="p-2 rounded-lg bg-amber-900/30 hover:bg-amber-800/40 transition-colors"
            >
              <Settings className="h-5 w-5 text-amber-400" />
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
