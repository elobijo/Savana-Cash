'use client';

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Wallet, 
  Send, 
  Download, 
  Copy, 
  Check, 
  QrCode,
  ArrowUpRight,
  ArrowDownLeft,
  RefreshCw,
  MoreHorizontal,
  Eye,
  EyeOff,
  TrendingUp,
  TrendingDown,
  Shield,
  Zap
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useWallet } from '@/contexts/WalletContext';
import { shortenAddress, copyToClipboard, formatFiat } from '@/lib/wallet/utils';
import { AFRICAN_CURRENCIES } from '@/types';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Drawer,
  DrawerContent,
  DrawerDescription,
  DrawerHeader,
  DrawerTitle,
} from '@/components/ui/drawer';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface WalletBalanceProps {
  onNavigate: (view: string) => void;
}

export function WalletBalance({ onNavigate }: WalletBalanceProps) {
  const { state, getBchBalance, getFiatBalance, setCurrency } = useWallet();
  const [copied, setCopied] = useState(false);
  const [showSendDialog, setShowSendDialog] = useState(false);
  const [showReceiveDialog, setShowReceiveDialog] = useState(false);
  const [balanceVisible, setBalanceVisible] = useState(true);

  const wallet = state.wallet;
  const bchBalance = getBchBalance();
  const fiatBalance = getFiatBalance();
  const mainAddress = wallet?.addresses[0]?.address || '';
  const bchPrice = state.tokens.find(t => t.symbol === 'BCH')?.price || 0;

  const handleCopyAddress = async () => {
    const success = await copyToClipboard(mainAddress);
    if (success) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  // Generate QR code data URL (simplified - in production use a QR library)
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(mainAddress)}`;

  return (
    <div className="space-y-4">
      {/* Balance Card */}
      <Card className="bg-gradient-to-br from-amber-600 via-orange-600 to-yellow-500 border-0 shadow-2xl overflow-hidden relative">
        {/* African Pattern Overlay */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0" style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M20 0L40 20L20 40L0 20L20 0z' fill='%23000' fill-opacity='0.1'/%3E%3C/svg%3E")`,
            backgroundSize: '40px 40px',
          }} />
        </div>
        
        <CardHeader className="pb-2 relative z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center backdrop-blur">
                <span className="text-lg font-bold text-white">₿</span>
              </div>
              <div>
                <CardDescription className="text-amber-100 text-xs">Bitcoin Cash</CardDescription>
                <CardTitle className="text-white text-lg">{wallet?.name || 'Wallet'}</CardTitle>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setBalanceVisible(!balanceVisible)}
              className="text-white/80 hover:bg-white/20 hover:text-white"
            >
              {balanceVisible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
            </Button>
          </div>
        </CardHeader>
        
        <CardContent className="relative z-10">
          <div className="space-y-1">
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-bold text-white">
                {balanceVisible ? bchBalance.toFixed(8) : '••••••••'}
              </span>
              <span className="text-xl text-white/80">BCH</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-lg text-white/90">
                {balanceVisible 
                  ? formatFiat(fiatBalance, state.settings.currency.code)
                  : '••••••'}
              </span>
              <Badge variant="secondary" className="bg-white/20 text-white border-0 text-xs">
                <TrendingUp className="h-3 w-3 mr-1" />
                +2.34%
              </Badge>
            </div>
          </div>

          {/* Quick Info */}
          <div className="flex items-center gap-4 mt-4 pt-4 border-t border-white/20">
            <div className="flex items-center gap-1.5 text-white/80 text-xs">
              <Zap className="h-3.5 w-3.5" />
              <span>~$0.001 fees</span>
            </div>
            <div className="flex items-center gap-1.5 text-white/80 text-xs">
              <Shield className="h-3.5 w-3.5" />
              <span>Non-custodial</span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 mt-4">
            <Button
              onClick={() => setShowSendDialog(true)}
              className="flex-1 bg-white/20 hover:bg-white/30 text-white border border-white/30 backdrop-blur"
            >
              <Send className="h-4 w-4 mr-2" />
              Send
            </Button>
            <Button
              onClick={() => setShowReceiveDialog(true)}
              className="flex-1 bg-white/20 hover:bg-white/30 text-white border border-white/30 backdrop-blur"
            >
              <Download className="h-4 w-4 mr-2" />
              Receive
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Currency Selector */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        {AFRICAN_CURRENCIES.slice(0, 6).map((currency) => (
          <Button
            key={currency.code}
            variant={state.settings.currency.code === currency.code ? 'default' : 'outline'}
            size="sm"
            onClick={() => setCurrency(currency.code)}
            className={`whitespace-nowrap ${
              state.settings.currency.code === currency.code
                ? 'bg-amber-500 hover:bg-amber-600 text-white'
                : 'border-amber-500/30 text-amber-100 hover:bg-amber-500/20'
            }`}
          >
            {currency.flag} {currency.code}
          </Button>
        ))}
      </div>

      {/* Address Card */}
      <Card className="bg-black/40 backdrop-blur border-amber-500/20">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-amber-200 mb-1">Your Address</p>
              <p className="text-sm font-mono text-white">{shortenAddress(mainAddress)}</p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleCopyAddress}
              className="text-amber-400 hover:bg-amber-500/20"
            >
              {copied ? <Check className="h-4 w-4 text-green-400" /> : <Copy className="h-4 w-4" />}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Recent Transactions */}
      <Card className="bg-black/40 backdrop-blur border-amber-500/20">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg text-white">Recent Activity</CardTitle>
            <Button variant="ghost" size="sm" className="text-amber-400 hover:bg-amber-500/20">
              <RefreshCw className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {state.transactions.length === 0 ? (
            <div className="text-center py-8">
              <Wallet className="h-12 w-12 text-amber-500/40 mx-auto mb-3" />
              <p className="text-amber-200/60 text-sm">No transactions yet</p>
            </div>
          ) : (
            <div className="space-y-3">
              {state.transactions.slice(0, 5).map((tx, index) => (
                <motion.div
                  key={tx.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-center gap-3 p-3 rounded-lg bg-amber-900/20 hover:bg-amber-900/30 transition-colors"
                >
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    tx.amount > 0 
                      ? 'bg-green-500/20 text-green-400' 
                      : 'bg-red-500/20 text-red-400'
                  }`}>
                    {tx.amount > 0 
                      ? <ArrowDownLeft className="h-5 w-5" />
                      : <ArrowUpRight className="h-5 w-5" />
                    }
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white font-medium capitalize">{tx.type}</p>
                    <p className="text-amber-200/60 text-xs truncate">{shortenAddress(tx.address)}</p>
                  </div>
                  <div className="text-right">
                    <p className={`font-semibold ${tx.amount > 0 ? 'text-green-400' : 'text-red-400'}`}>
                      {tx.amount > 0 ? '+' : ''}{tx.amount.toFixed(8)} BCH
                    </p>
                    <p className="text-amber-200/60 text-xs">
                      {new Date(tx.timestamp).toLocaleDateString()}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Send Dialog */}
      <Dialog open={showSendDialog} onOpenChange={setShowSendDialog}>
        <DialogContent className="bg-gradient-to-br from-amber-950 to-orange-950 border-amber-500/30">
          <DialogHeader>
            <DialogTitle className="text-white">Send BCH</DialogTitle>
            <DialogDescription className="text-amber-200">
              Send Bitcoin Cash to any address
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <div className="space-y-2">
              <Label className="text-amber-100">Recipient Address</Label>
              <Input
                placeholder="bitcoincash:q..."
                className="bg-amber-900/30 border-amber-500/30 text-white placeholder:text-amber-200/50"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-amber-100">Amount (BCH)</Label>
              <Input
                type="number"
                placeholder="0.00"
                className="bg-amber-900/30 border-amber-500/30 text-white placeholder:text-amber-200/50"
              />
              <p className="text-xs text-amber-200/60">
                Available: {bchBalance.toFixed(8)} BCH
              </p>
            </div>
            <div className="bg-amber-900/30 rounded-lg p-3">
              <div className="flex justify-between text-sm">
                <span className="text-amber-200">Network Fee</span>
                <span className="text-white">~$0.001</span>
              </div>
              <div className="flex justify-between text-sm mt-1">
                <span className="text-amber-200">Confirmation</span>
                <span className="text-white">~2 seconds</span>
              </div>
            </div>
            <Button className="w-full bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white">
              Send BCH
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Receive Dialog */}
      <Dialog open={showReceiveDialog} onOpenChange={setShowReceiveDialog}>
        <DialogContent className="bg-gradient-to-br from-amber-950 to-orange-950 border-amber-500/30">
          <DialogHeader>
            <DialogTitle className="text-white">Receive BCH</DialogTitle>
            <DialogDescription className="text-amber-200">
              Scan or copy your address
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col items-center pt-4">
            <div className="bg-white p-4 rounded-xl">
              <img src={qrCodeUrl} alt="QR Code" className="w-48 h-48" />
            </div>
            <div className="mt-4 w-full">
              <div className="flex items-center gap-2 bg-amber-900/30 rounded-lg p-3">
                <p className="flex-1 text-xs font-mono text-amber-100 break-all">{mainAddress}</p>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handleCopyAddress}
                  className="text-amber-400 hover:bg-amber-500/20 shrink-0"
                >
                  {copied ? <Check className="h-4 w-4 text-green-400" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
