'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Wallet, 
  Key, 
  Shield, 
  Copy, 
  Check, 
  AlertTriangle,
  ArrowRight,
  Eye,
  EyeOff,
  Wordlight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useWallet } from '@/contexts/WalletContext';
import { copyToClipboard } from '@/lib/wallet/utils';

interface WalletCreationProps {
  onComplete: () => void;
}

export function WalletCreation({ onComplete }: WalletCreationProps) {
  const { createNewWallet, importExistingWallet, state } = useWallet();
  const [step, setStep] = useState<'choose' | 'create' | 'backup' | 'import'>('choose');
  const [walletName, setWalletName] = useState('My BCH Wallet');
  const [mnemonic, setMnemonic] = useState('');
  const [importMnemonic, setImportMnemonic] = useState('');
  const [showMnemonic, setShowMnemonic] = useState(false);
  const [copied, setCopied] = useState(false);
  const [backupConfirmed, setBackupConfirmed] = useState(false);
  const [error, setError] = useState('');

  const handleCreateWallet = () => {
    createNewWallet(walletName);
    setStep('backup');
  };

  const handleImportWallet = () => {
    const success = importExistingWallet(importMnemonic.trim());
    if (success) {
      onComplete();
    } else {
      setError('Invalid mnemonic phrase. Please check and try again.');
    }
  };

  const handleCopyMnemonic = async () => {
    if (state.wallet?.mnemonic) {
      const success = await copyToClipboard(state.wallet.mnemonic);
      if (success) {
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      }
    }
  };

  const handleBackupComplete = () => {
    if (backupConfirmed) {
      onComplete();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-950 via-orange-950 to-yellow-900 flex items-center justify-center p-4">
      {/* African Pattern Background */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M30 0L60 30L30 60L0 30L30 0z' fill='%23ffffff' fill-opacity='0.1'/%3E%3C/svg%3E")`,
          backgroundSize: '60px 60px',
        }} />
      </div>

      <AnimatePresence mode="wait">
        {step === 'choose' && (
          <motion.div
            key="choose"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="w-full max-w-md relative z-10"
          >
            <Card className="bg-black/40 backdrop-blur-xl border-amber-500/30 shadow-2xl">
              <CardHeader className="text-center">
                <div className="mx-auto w-16 h-16 bg-gradient-to-br from-amber-400 to-orange-600 rounded-2xl flex items-center justify-center mb-4 shadow-lg">
                  <span className="text-3xl font-bold text-white">₿</span>
                </div>
                <CardTitle className="text-2xl font-bold text-white">Savanna Cash</CardTitle>
                <CardDescription className="text-amber-200">
                  Bitcoin Cash Wallet for Africa
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-center text-amber-100/80 text-sm">
                  Fast, affordable, and borderless electronic cash. Made for Africa.
                </p>
                <div className="bg-amber-900/30 rounded-lg p-3 text-center">
                  <p className="text-amber-200 text-xs">
                    💰 Transaction fees under $0.001<br/>
                    ⚡ Confirmations in seconds<br/>
                    🌍 Works everywhere in Africa
                  </p>
                </div>
              </CardContent>
              <CardFooter className="flex flex-col gap-3">
                <Button
                  onClick={() => setStep('create')}
                  className="w-full bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-semibold py-6 text-lg rounded-xl shadow-lg"
                >
                  <Wallet className="mr-2 h-5 w-5" />
                  Create New Wallet
                </Button>
                <Button
                  onClick={() => setStep('import')}
                  variant="outline"
                  className="w-full border-amber-500/50 text-amber-100 hover:bg-amber-500/20 py-6 text-lg rounded-xl"
                >
                  <Key className="mr-2 h-5 w-5" />
                  Import Existing Wallet
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        )}

        {step === 'create' && (
          <motion.div
            key="create"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="w-full max-w-md relative z-10"
          >
            <Card className="bg-black/40 backdrop-blur-xl border-amber-500/30 shadow-2xl">
              <CardHeader>
                <CardTitle className="text-xl font-bold text-white">Name Your Wallet</CardTitle>
                <CardDescription className="text-amber-200">
                  Give your wallet a memorable name
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="walletName" className="text-amber-100">Wallet Name</Label>
                  <Input
                    id="walletName"
                    value={walletName}
                    onChange={(e) => setWalletName(e.target.value)}
                    placeholder="My BCH Wallet"
                    className="bg-amber-900/30 border-amber-500/30 text-white placeholder:text-amber-200/50"
                  />
                </div>
              </CardContent>
              <CardFooter className="flex gap-3">
                <Button
                  onClick={() => setStep('choose')}
                  variant="ghost"
                  className="text-amber-200 hover:bg-amber-500/20"
                >
                  Back
                </Button>
                <Button
                  onClick={handleCreateWallet}
                  className="flex-1 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-semibold"
                >
                  Continue
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        )}

        {step === 'backup' && state.wallet?.mnemonic && (
          <motion.div
            key="backup"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="w-full max-w-md relative z-10"
          >
            <Card className="bg-black/40 backdrop-blur-xl border-amber-500/30 shadow-2xl">
              <CardHeader>
                <div className="flex items-center gap-2 mb-2">
                  <Shield className="h-6 w-6 text-amber-400" />
                  <CardTitle className="text-xl font-bold text-white">Backup Your Wallet</CardTitle>
                </div>
                <CardDescription className="text-amber-200">
                  Write down these 12 words in order and keep them safe
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Alert className="bg-red-900/30 border-red-500/50">
                  <AlertTriangle className="h-4 w-4 text-red-400" />
                  <AlertDescription className="text-red-200 text-sm">
                    Anyone with these words can access your wallet. Never share them!
                  </AlertDescription>
                </Alert>

                <div className="relative">
                  <div className="bg-amber-900/40 rounded-xl p-4 border border-amber-500/30">
                    <div className="grid grid-cols-3 gap-2">
                      {state.wallet.mnemonic.split(' ').map((word, index) => (
                        <div key={index} className="flex items-center gap-2 bg-black/20 rounded-lg px-3 py-2">
                          <span className="text-amber-400 text-xs font-mono">{index + 1}.</span>
                          <span className="text-white font-medium">{showMnemonic ? word : '•••••'}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="absolute top-2 right-2 flex gap-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setShowMnemonic(!showMnemonic)}
                      className="text-amber-200 hover:bg-amber-500/20"
                    >
                      {showMnemonic ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={handleCopyMnemonic}
                      className="text-amber-200 hover:bg-amber-500/20"
                    >
                      {copied ? <Check className="h-4 w-4 text-green-400" /> : <Copy className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>

                <label className="flex items-start gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={backupConfirmed}
                    onChange={(e) => setBackupConfirmed(e.target.checked)}
                    className="mt-1 h-4 w-4 rounded border-amber-500/50 bg-amber-900/30 text-amber-500 focus:ring-amber-500"
                  />
                  <span className="text-sm text-amber-100">
                    I have written down my recovery phrase and stored it in a safe place
                  </span>
                </label>
              </CardContent>
              <CardFooter className="flex gap-3">
                <Button
                  onClick={() => setStep('create')}
                  variant="ghost"
                  className="text-amber-200 hover:bg-amber-500/20"
                >
                  Back
                </Button>
                <Button
                  onClick={handleBackupComplete}
                  disabled={!backupConfirmed}
                  className="flex-1 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-semibold disabled:opacity-50"
                >
                  Complete Setup
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        )}

        {step === 'import' && (
          <motion.div
            key="import"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="w-full max-w-md relative z-10"
          >
            <Card className="bg-black/40 backdrop-blur-xl border-amber-500/30 shadow-2xl">
              <CardHeader>
                <CardTitle className="text-xl font-bold text-white">Import Wallet</CardTitle>
                <CardDescription className="text-amber-200">
                  Enter your 12 or 24 word recovery phrase
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {error && (
                  <Alert className="bg-red-900/30 border-red-500/50">
                    <AlertTriangle className="h-4 w-4 text-red-400" />
                    <AlertDescription className="text-red-200 text-sm">{error}</AlertDescription>
                  </Alert>
                )}
                <div className="space-y-2">
                  <Label htmlFor="mnemonic" className="text-amber-100">Recovery Phrase</Label>
                  <textarea
                    id="mnemonic"
                    value={importMnemonic}
                    onChange={(e) => {
                      setImportMnemonic(e.target.value);
                      setError('');
                    }}
                    placeholder="word1 word2 word3 word4 word5 word6 word7 word8 word9 word10 word11 word12"
                    className="w-full h-24 px-3 py-2 bg-amber-900/30 border border-amber-500/30 rounded-lg text-white placeholder:text-amber-200/50 focus:outline-none focus:ring-2 focus:ring-amber-500 resize-none"
                  />
                </div>
                <p className="text-xs text-amber-200/60">
                  Enter your recovery phrase separated by spaces. The order matters!
                </p>
              </CardContent>
              <CardFooter className="flex gap-3">
                <Button
                  onClick={() => setStep('choose')}
                  variant="ghost"
                  className="text-amber-200 hover:bg-amber-500/20"
                >
                  Back
                </Button>
                <Button
                  onClick={handleImportWallet}
                  disabled={!importMnemonic.trim()}
                  className="flex-1 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-semibold disabled:opacity-50"
                >
                  Import Wallet
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
